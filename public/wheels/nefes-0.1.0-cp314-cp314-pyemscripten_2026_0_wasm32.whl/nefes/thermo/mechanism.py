"""Reaction sets and the :class:`Mechanism` (species set + reactions).

The thermochemical *material database* is a :class:`~nefes.thermo.species.SpeciesSet`, a
set of species with their NASA polynomials, and all that chemical equilibrium needs. A
**mechanism** is the *combination* of such a species set with a set of **reactions** whose
participants refer to species in that species_set. Reactions are needed only for the
finite-rate path and for the shared-Gibbs ``K_c`` route; equilibrium and mixture
properties never need them.

Reaction stoichiometry and modified-Arrhenius data are carried; mechanisms load from
Cantera's YAML format through :meth:`Mechanism.from_cantera`, which reads a file path
directly (a round-tripping subset of the format) or extracts from a live
``cantera.Solution``. ``Mechanism`` proxies the species set's thermo interface so it can be
passed anywhere a :class:`SpeciesSet` is expected.

Public: :class:`Reaction`, :class:`Mechanism`.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field

import yaml

from .species import (
    SpeciesSet,
    _parse_cantera_doc,
)

__all__ = ["Reaction", "Mechanism"]


@dataclass
class Reaction:
    """Elementary reaction with modified-Arrhenius parameters.

    Stored for the finite-rate path. The rate machinery itself is not implemented; only the
    data and the shared ``K_c`` route (via species Gibbs energies) are wired.
    """

    reactants: dict  # species name -> stoichiometric coefficient
    products: dict
    A: float  # pre-exponential [units per mechanism convention]
    b: float  # temperature exponent
    Ea: float  # activation energy [J/mol]
    reversible: bool = True
    equation: str = ""


@dataclass
class Mechanism:
    """A species set together with a set of reactions over its species.

    ``species_set`` carries the species/thermo data (and the element matrix used by
    the equilibrium kernel); ``reactions`` is the kinetic data.  Thermo and
    sizing attributes are proxied to the species set, so a ``Mechanism`` is accepted
    anywhere a :class:`SpeciesSet` is.
    """

    species_set: SpeciesSet
    reactions: list = field(default_factory=list)

    # -- proxy the species set's thermo / sizing surface ---------------------
    @property
    def elements(self):
        return self.species_set.elements

    @property
    def species(self):
        return self.species_set.species

    @property
    def species_index(self):
        return self.species_set.species_index

    @property
    def element_index(self):
        return self.species_set.element_index

    @property
    def molar_masses(self):
        return self.species_set.molar_masses

    @property
    def element_matrix(self):
        return self.species_set.element_matrix

    @property
    def element_weights(self):
        return self.species_set.element_weights

    @property
    def P_ref(self):
        return self.species_set.P_ref

    @property
    def n_species(self):
        return self.species_set.n_species

    @property
    def n_elements(self):
        return self.species_set.n_elements

    def cp_R(self, T):
        return self.species_set.cp_R(T)

    def h_RT(self, T):
        return self.species_set.h_RT(T)

    def s_R(self, T):
        return self.species_set.s_R(T)

    def g_RT(self, T):
        return self.species_set.g_RT(T)

    # -- loaders ---------------------------------------------------------
    @classmethod
    def from_cantera(cls, source):
        """Build a mechanism (species set + reactions) from Cantera data.

        ``source`` may be a Cantera-YAML file path (``str``/``os.PathLike``), an
        already-parsed ``dict``, or a live ``cantera.Solution``. Paths and dicts are read
        directly with no Cantera dependency; a ``cantera.Solution`` is extracted through
        Cantera, so passing one requires Cantera to be installed.
        """
        if isinstance(source, (str, os.PathLike)):
            with open(source, "r") as fh:
                source = yaml.safe_load(fh)
        if isinstance(source, dict):
            return cls.from_dict(source)
        # A live cantera.Solution: extract the species set and reactions through Cantera.
        species_set = SpeciesSet.from_cantera(source)
        reactions = [_reaction_from_cantera(rxn) for rxn in source.reactions()]
        return cls(species_set=species_set, reactions=reactions)

    @classmethod
    def from_dict(cls, doc):
        """Build a mechanism from an already-parsed Cantera-YAML document."""
        elements, species, raw_reactions = _parse_cantera_doc(doc)
        species_set = SpeciesSet(elements=elements, species=species)
        reactions = [_reaction_from_dict(r) for r in raw_reactions]
        return cls(species_set=species_set, reactions=reactions)

    # -- writer ----------------------------------------------------------
    def to_cantera_dict(self):
        """Serialize to a Cantera-YAML-compatible dict (round-trips with :meth:`from_dict`)."""
        doc = self.species_set.to_cantera_dict()
        if self.reactions:
            doc["reactions"] = [
                {
                    "equation": r.equation or _format_equation(r),
                    "rate-constant": {"A": r.A, "b": r.b, "Ea": r.Ea},
                }
                for r in self.reactions
            ]
        return doc

    def write_cantera_yaml(self, path):
        with open(path, "w") as fh:
            yaml.safe_dump(self.to_cantera_dict(), fh, sort_keys=False)


def _reaction_from_cantera(rxn):
    rate = getattr(rxn, "rate", None)
    A = getattr(rate, "pre_exponential_factor", float("nan")) if rate else float("nan")
    b = getattr(rate, "temperature_exponent", 0.0) if rate else 0.0
    # Cantera activation_energy is J/kmol -> J/mol.
    Ea = (getattr(rate, "activation_energy", 0.0) if rate else 0.0) * 1e-3
    return Reaction(
        reactants=dict(rxn.reactants),
        products=dict(rxn.products),
        A=A,
        b=b,
        Ea=Ea,
        reversible=rxn.reversible,
        equation=rxn.equation,
    )


def _reaction_from_dict(r):
    eq = r.get("equation", "")
    reactants, products = _parse_equation(eq) if eq else ({}, {})
    rc = r.get("rate-constant", {}) or {}
    return Reaction(
        reactants=reactants,
        products=products,
        A=rc.get("A", float("nan")),
        b=rc.get("b", 0.0),
        Ea=rc.get("Ea", 0.0),
        reversible="<=>" in eq or ("=" in eq and "=>" not in eq),
        equation=eq,
    )


def _parse_equation(eq):
    """Parse a reaction equation into reactant/product stoichiometry dicts."""
    for arrow in ("<=>", "=>", "="):
        if arrow in eq:
            lhs, rhs = eq.split(arrow)
            break
    else:
        return {}, {}

    def side(text):
        out = {}
        for term in text.split("+"):
            term = term.strip()
            if not term or term.upper() == "M":
                continue
            coeff = 1.0
            k = 0
            while k < len(term) and (term[k].isdigit() or term[k] == "."):
                k += 1
            if k > 0:
                coeff = float(term[:k])
                term = term[k:].strip()
            out[term] = out.get(term, 0.0) + coeff
        return out

    return side(lhs), side(rhs)


def _format_equation(r):
    """Render a reaction's stoichiometry as an equation string."""

    def side(d):
        return " + ".join(sp if nu == 1 else f"{nu:g} {sp}" for sp, nu in d.items())

    arrow = " <=> " if r.reversible else " => "
    return side(r.reactants) + arrow + side(r.products)
