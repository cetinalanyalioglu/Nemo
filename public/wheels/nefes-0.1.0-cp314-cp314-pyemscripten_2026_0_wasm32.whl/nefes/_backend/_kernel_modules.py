"""The inventory of kernel modules: what a complete ahead-of-time build covers.

One list, read by two readers that must not disagree.  The build compiles every module
here that has a declaration file beside it, and the runtime reports which of them the
running session actually got compiled.  A module missing from a build is not an error but
it is never silent: under the ahead-of-time backend an uncompiled kernel falls back to
plain Python, which is orders of magnitude slower than either compiler, and that is the
one failure that would otherwise look like success.

Paths are relative to ``nefes``.  Deliberately kept free of imports so the build can read
it before the package (or numpy, or a compiler) is available.

``assembly._prim`` is absent on purpose: its compiled form is a declaration-only header
inlined into its callers rather than a module of its own, so there is nothing to build and
nothing to count.
"""

KERNEL_MODULES = (
    # leaves first: these are what everything else calls
    "assembly.smooth",
    "assembly.dense",
    # thermochemistry
    "thermo.perfect_gas",
    "thermo.kernel",
    "thermo.edge_state",
    "thermo.api",
    # the assembly path, which calls all of the above
    "assembly.closure",
    "assembly.recover",
    "elements.kernels",
    "assembly.assemble",
)
