"""A no-op stand-in for the ``cython`` module, for installs that never compile anything.

The kernel sources are written in Cython's pure-Python mode: ordinary Python that an
ahead-of-time build can turn into C, annotated with ``cython.*`` decorators and types
that mean nothing at run time.  Reading those annotations therefore costs an ``import
cython`` -- on every backend, including the two that never compile.

Cython supplies such a stand-in itself (``Cython.Shadow``), but only as part of the
compiler, which is some fifteen megabytes of package that a numba install has no other
use for.  This is the subset those sources actually reach for, so the default install
keeps its dependencies.  It is registered as ``cython`` in :mod:`sys.modules` by
:mod:`nefes._backend`, and only when the real one is absent -- where Cython *is*
installed, its own shim is used and this file is never loaded.

Everything here is deliberately inert.  ``compiled`` is ``False``, every decorator
returns its function untouched, and every type is a marker object that exists only to
be read as an annotation.  Under a real Cython build none of it runs: the compiler
resolves the same names statically and emits C.
"""

import sys

__all__ = ["install"]

compiled = False  # the compiler sets this True; folded to a constant by numba and Cython alike


class _Type:
    """A stand-in for a Cython type, usable as an annotation and nothing more."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return f"cython.{self._name}"

    def __call__(self, *args, **kwargs):
        # `cython.double(x)` casts when compiled; uncompiled the value passes through
        return args[0] if args else None

    def __getitem__(self, item):
        # memoryview and array spellings: `cython.double[::1]`
        return self


class _FusedType(_Type):
    """A stand-in for ``cython.fused_type``: a set of alternatives, inert at run time."""

    __slots__ = ("types",)

    def __init__(self, *types):
        super().__init__("fused")
        self.types = types


def fused_type(*args):
    """Declare a fused (generic) type.  Inert here; the compiler specializes on it."""
    return _FusedType(*args)


def _identity(fn):
    """Return ``fn`` unchanged."""
    return fn


def _identity_decorator_factory(*args, **kwargs):
    """Accept any arguments and return a decorator that changes nothing."""
    if len(args) == 1 and not kwargs and callable(args[0]):
        return args[0]
    return _identity


# Declaration decorators.  Compiled, these choose the calling convention and the
# exception behaviour; uncompiled they must leave the function exactly as written.
cfunc = _identity
ccall = _identity
cclass = _identity
inline = _identity
nogil = _identity
with_gil = _identity
exceptval = _identity_decorator_factory
locals = _identity_decorator_factory  # noqa: A001 -- the name is Cython's
returns = _identity_decorator_factory
boundscheck = _identity_decorator_factory
wraparound = _identity_decorator_factory
cdivision = _identity_decorator_factory
final = _identity

# The scalar types the kernels annotate with.
void = _Type("void")
bint = _Type("bint")
char = _Type("char")
short = _Type("short")
int = _Type("int")  # noqa: A001 -- these shadow builtins in Cython too
long = _Type("long")  # noqa: A001
longlong = _Type("longlong")
size_t = _Type("size_t")
Py_ssize_t = _Type("Py_ssize_t")
float = _Type("float")  # noqa: A001
double = _Type("double")
longdouble = _Type("longdouble")
floatcomplex = _Type("floatcomplex")
doublecomplex = _Type("doublecomplex")
complex = _Type("complex")  # noqa: A001


def declare(typ=None, value=None, **kwargs):
    """Declare a typed local.  Uncompiled it simply hands back the initial value."""
    return value


def address(x):
    """Address-of.  Meaningless uncompiled; returned as-is so a read still works."""
    return x


def cast(typ, value, *args, **kwargs):
    """Cast to a Cython type.  Uncompiled the value is already what Python makes of it."""
    return value


def sizeof(_x):
    """Size of a type in bytes; unknowable here, and never used off the compiled path."""
    return 1


def __getattr__(name):
    """Any name this subset missed resolves to an inert decorator rather than failing.

    The sources only reach the names above, but Cython's surface is wide and a
    ``AttributeError`` from a shim would be a confusing way to learn that.
    """
    if name.startswith("__"):
        raise AttributeError(name)
    return _identity_decorator_factory


def install():
    """Register this module as ``cython`` unless the real one is importable.

    Returns
    -------
    bool
        ``True`` if this shim was installed, ``False`` if a real ``cython`` was found
        and left in place.
    """
    if "cython" in sys.modules:
        return False
    try:
        import cython  # noqa: F401

        return False
    except ImportError:
        sys.modules["cython"] = sys.modules[__name__]
        return True
