"""Which implementation of the compiled kernels a session runs on.

One set of kernel sources serves three backends, and this module decides which of
them is in play before any kernel is imported:

* ``numba`` -- the sources are compiled at run time by numba.  The default, and
  what every install has always used.
* ``accel`` -- the same sources, compiled ahead of time by Cython and imported
  from the built extension modules.  Needed where no compiler exists at run time
  (a browser), and it removes the just-in-time warm-up on a first solve.
* ``python`` -- the sources run as plain Python.  Far slower, but it needs no
  compiler at all, it is what a debugger can step through, and it is the
  reference the other two are checked against.

The backend follows the ``NEFES_BACKEND`` environment variable, whose default
``auto`` takes the fastest one available.  Naming a backend that is not installed
is an error rather than a silent downgrade, so a run never quietly loses the
performance it was asked for.

The kernels take their ``njit`` from here rather than from numba directly.  Under
the numba backend it *is* numba's; under the other two it is a no-op, because
those backends are either already compiled or deliberately not compiling.

Examples
--------
Report what is running, and force the plain-Python reference::

    >>> import nefes
    >>> nefes.backend()                                   # doctest: +SKIP
    'numba'
    >>> import os; os.environ["NEFES_BACKEND"] = "python"  # before importing nefes

Public: :data:`BACKEND`, :func:`backend`, :func:`available`, :func:`njit`.
"""

import importlib.util
import os
import warnings

__all__ = ["BACKEND", "backend", "available", "coverage", "backend_report", "njit"]

# Preference order for ``auto``: the first installed backend wins, and ``python`` is
# always installed, so the walk always terminates.
#
# numba comes before the ahead-of-time build deliberately.  Only the modules listed in
# the build cover the kernels; anything not yet compiled falls back to plain Python
# under the accel backend, which for a partial port is far slower than numba rather
# than faster.  So accel is what a session gets when numba cannot run at all -- a
# browser -- or when it is asked for by name.  Once the build covers every kernel
# module this order is worth revisiting, since the compiled path also has no warm-up.
_ORDER = ("numba", "accel", "python")
_VALID = ("accel", "numba", "python", "auto")


def _accel_dir() -> str:
    """Where the ahead-of-time build puts its compiled kernels."""
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "_accel")


def _accel_available(accel: str = None) -> bool:
    """Whether the ahead-of-time compiled kernels were built into this install.

    Located on disk rather than by importing: this runs while ``nefes._backend`` is
    still initializing, and importing anything under ``nefes`` here would re-enter the
    package before the kernels have a ``njit`` to bind.

    What is looked for is a built extension, not the tree it sits in.  The build
    mirrors each kernel source into ``_accel`` before compiling it, so a tree that
    holds only those copies -- an install that shipped them without a compiler, or a
    build that stopped part way -- would otherwise announce a backend that cannot run.

    Parameters
    ----------
    accel : str, optional
        The directory to look in; defaults to this install's own.
    """
    accel = _accel_dir() if accel is None else accel
    if not os.path.isfile(os.path.join(accel, "__init__.py")):
        return False
    for _root, _dirs, files in os.walk(accel):
        if any(f.endswith((".so", ".pyd")) for f in files):
            return True
    return False


def _numba_available() -> bool:
    """Whether numba can be imported (it is an ordinary install dependency)."""
    try:
        import numba  # noqa: F401
    except ImportError:
        return False
    return True


_AVAILABLE = {"accel": _accel_available, "numba": _numba_available, "python": lambda: True}


def available() -> tuple:
    """Backends this install can actually run, fastest first.

    Returns
    -------
    tuple of str
        A subset of ``("numba", "accel", "python")``, in the order ``auto`` prefers them.

    Examples
    --------
    >>> from nefes._backend import available
    >>> "python" in available()
    True
    """
    return tuple(name for name in _ORDER if _AVAILABLE[name]())


def _resolve() -> str:
    """Pick the backend for this session from ``NEFES_BACKEND`` and what is installed."""
    want = os.environ.get("NEFES_BACKEND", "auto").strip().lower() or "auto"
    if want not in _VALID:
        raise ValueError(f"NEFES_BACKEND must be one of {_VALID}, got {want!r}")
    if want != "auto":
        if not _AVAILABLE[want]():
            raise ImportError(
                f"NEFES_BACKEND={want!r} was requested but that backend is not installed "
                f"(available: {', '.join(available())}). "
                + (
                    "Build the compiled kernels with NEFES_BUILD_ACCEL=1 pip install -e ."
                    if want == "accel"
                    else "Install numba, or use NEFES_BACKEND=python."
                )
            )
        return want
    chosen = available()[0]
    if chosen == "python":
        warnings.warn(
            "running the kernels as plain Python: no compiled backend is installed, so solves "
            "will be orders of magnitude slower. Install numba, or build the compiled kernels "
            "with NEFES_BUILD_ACCEL=1 pip install -e .",
            RuntimeWarning,
            stacklevel=2,
        )
    return chosen


BACKEND = _resolve()

# The kernel sources carry Cython pure-Python-mode annotations, so reading them costs an
# ``import cython`` on every backend.  Where the compiler is not installed, a no-op subset
# stands in for it (see :mod:`nefes._backend._cython_shim`); where it is, its own shim is
# left alone.  This runs before any kernel module is imported.
from ._cython_shim import install as _install_cython_shim  # noqa: E402

USING_CYTHON_SHIM = _install_cython_shim()


def backend() -> str:
    """The backend this session resolved to.

    Returns
    -------
    str
        ``"accel"``, ``"numba"`` or ``"python"``.
    """
    return BACKEND


def _no_jit(*args, **kwargs):
    """Stand in for ``numba.njit`` where nothing is compiled at run time.

    Accepts the bare and the called decorator forms, and ignores every option, so a
    kernel's ``@njit(cache=True)`` reads the same whichever backend is active.
    """
    if len(args) == 1 and not kwargs and callable(args[0]):
        return args[0]

    def wrap(fn):
        return fn

    return wrap


if BACKEND == "numba":
    from numba import njit
else:
    njit = _no_jit


class _AccelRedirect:
    """Serve the compiled twin of a kernel module in place of its source.

    The ahead-of-time build compiles each kernel module into ``nefes._accel``, mirroring
    the package layout, rather than beside its source.  Keeping them apart is what lets a
    built install still run on any backend, so the three can be compared; the cost is that
    something has to point imports at the compiled copy, which is this.

    Registered on :data:`sys.meta_path` only under the accel backend, and only for the
    modules the build actually produced.  Every other import is untouched.

    This sits ahead of the ordinary import machinery, so it is asked about every module
    a session loads and must answer without importing anything itself: an import taken
    here would be asked back through this same hook.  Hence the map lookup first, and
    :mod:`importlib.util` brought in at the top of this file rather than on use.
    """

    def __init__(self, modules):
        self._map = {f"nefes.{name}": f"nefes._accel.{name}" for name in modules}

    def find_module(self, fullname, path=None):  # pragma: no cover - legacy hook
        return None

    def find_spec(self, fullname, path=None, target=None):
        """Hand back the compiled module's spec when one is registered for this name."""
        target_name = self._map.get(fullname)
        if target_name is None:
            return None
        spec = importlib.util.find_spec(target_name)
        if spec is None:  # a listed module that did not build: fall through to the source
            return None
        spec = importlib.util.spec_from_file_location(fullname, spec.origin, loader=spec.loader)
        return spec


def _install_accel_redirect():
    """Point the compiled kernel modules' import names at ``nefes._accel``."""
    import sys

    marker = os.path.join(_accel_dir(), "__init__.py")
    names = {}
    with open(marker) as fh:
        for line in fh:
            if line.startswith("MODULES = "):
                names = eval(line.split("=", 1)[1].strip())  # a literal list written by the build
                break
    if names:
        sys.meta_path.insert(0, _AccelRedirect(names))
    return tuple(names)


ACCEL_MODULES = _install_accel_redirect() if BACKEND == "accel" else ()


def coverage():
    """Which kernel modules this session runs compiled, and which fall back.

    Returns
    -------
    compiled : tuple of str
        Kernel modules served from the ahead-of-time build.
    interpreted : tuple of str
        Kernel modules that are *not*, and so run as plain Python under the ahead-of-time
        backend.  Empty under numba, which compiles all of them at run time, and the whole
        inventory under the plain-Python backend, which compiles none of them.

    See also
    --------
    backend_report : the same information as a printable summary.

    Examples
    --------
    >>> from nefes._backend import coverage
    >>> compiled, interpreted = coverage()
    >>> isinstance(compiled, tuple) and isinstance(interpreted, tuple)
    True
    """
    from ._kernel_modules import KERNEL_MODULES

    if BACKEND == "numba":
        return tuple(KERNEL_MODULES), ()
    if BACKEND == "python":
        return (), tuple(KERNEL_MODULES)
    built = set(ACCEL_MODULES)
    return (
        tuple(m for m in KERNEL_MODULES if m in built),
        tuple(m for m in KERNEL_MODULES if m not in built),
    )


def backend_report():
    """A printable summary of the active backend and its kernel coverage.

    Returns
    -------
    str

    Examples
    --------
    >>> import nefes
    >>> print(nefes.backend_report())            # doctest: +SKIP
    """
    from ._kernel_modules import KERNEL_MODULES

    compiled, interpreted = coverage()
    total = len(KERNEL_MODULES)
    lines = [
        f"backend            : {BACKEND}",
        f"available          : {', '.join(available())}",
        f"kernel modules     : {len(compiled)}/{total} compiled",
    ]
    if BACKEND == "numba":
        lines.append("                     (numba compiles every kernel at run time)")
    elif interpreted:
        lines.append("")
        lines.append("running as plain Python, orders of magnitude slower than either compiler:")
        lines.extend(f"    nefes.{name}" for name in interpreted)
        if BACKEND == "accel":
            lines.append("")
            lines.append("    build them with NEFES_BUILD_ACCEL=1 pip install -e .[accel]")
    return "\n".join(lines)


def _warn_partial_coverage():
    """Say so, loudly, when the compiled backend is only partly compiled.

    Under this backend an uncompiled kernel does not fall back to numba -- there is no
    run-time compiler in play at all -- it falls back to plain Python.  A partial build is
    therefore far slower than not building at all, and slow in a way that looks like
    working, so it is never left to be discovered by profiling.
    """
    _compiled, interpreted = coverage()
    if not interpreted:
        return
    warnings.warn(
        f"the compiled backend covers {len(_compiled)} of {len(_compiled) + len(interpreted)} "
        f"kernel modules; the rest run as plain Python and will dominate every solve: "
        f"{', '.join(interpreted)}. Build them (NEFES_BUILD_ACCEL=1 pip install -e .[accel]), "
        f"or use NEFES_BACKEND=numba. nefes.backend_report() shows the breakdown.",
        RuntimeWarning,
        stacklevel=3,
    )


if BACKEND == "accel":
    _warn_partial_coverage()


def jit_kernels(module_name, names, **options):
    """Compile a module's kernels in place, on the backends that compile at run time.

    A kernel module cannot carry ``@njit`` on its definitions.  The ahead-of-time
    compiler needs to see a bare ``def`` to give it a C calling convention, and a
    decorator applied at run time hides that.  So the decoration happens here instead,
    once the module is fully defined, by rebinding each name in the module's own
    namespace -- which is also the namespace the kernels resolve each other through, so
    a kernel calling another still reaches the compiled one.

    Does nothing under the ahead-of-time and plain-Python backends: the first is already
    compiled, and the second is deliberately not.

    Parameters
    ----------
    module_name : str
        ``__name__`` of the calling module.
    names : sequence of str
        The kernels to compile, in the order they should be bound.
    **options
        Passed to ``numba.njit`` (default ``cache=True``).

    Returns
    -------
    None

    Examples
    --------
    At the foot of a kernel module::

        jit_kernels(__name__, ("smooth_abs", "smooth_step"))
    """
    if BACKEND != "numba":
        return
    import sys

    options.setdefault("cache", True)
    module = sys.modules[module_name]
    for name in names:
        fn = getattr(module, name)
        setattr(module, name, njit(**options)(fn))
