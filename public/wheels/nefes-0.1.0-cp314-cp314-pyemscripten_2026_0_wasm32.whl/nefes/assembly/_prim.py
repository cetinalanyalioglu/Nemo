"""Elementary math the kernels call, in the form the interpreted backends need.

The kernels are dtype-generic: the same body evaluates a real residual and carries a
complex-step seed.  Numpy gives that for free -- ``np.sqrt`` dispatches on the argument
-- so on the numba and plain-Python backends these are one-line wrappers and the backend
compiles them along with everything else.

C has no such dispatch, so the ahead-of-time build cannot use this file: it takes the
same names from ``_prim.pxd``, where each is a fused-type inline function resolving to
``sqrt`` or ``csqrt`` at compile time.  That header and this module are the *only* place
the two spellings exist; every kernel body above them is shared, and calls these by name.

Public: :func:`ksqrt`, :func:`kexp`, :func:`klog`, :func:`kreal`, :func:`kzeros`,
:func:`kview2`, :func:`kview3`, :func:`kviewi`, :func:`kviewb`, :func:`kscratch`.
"""

import numpy as np

from .._backend import BACKEND, jit_kernels

__all__ = [
    "ksqrt",
    "kexp",
    "klog",
    "kreal",
    "kzeros",
    "kview2",
    "kview3",
    "kviewi",
    "kviewb",
    "kscratch",
]


def ksqrt(z):
    """Square root of a real or complex argument.

    Parameters
    ----------
    z : float or complex
        Radicand.  Every caller in this package guarantees it is strictly positive on
        the real axis, so the complex branch never approaches the cut on ``(-inf, 0]``
        and the complex-step derivative through it stays exact.

    Returns
    -------
    float or complex
        ``sqrt(z)``, at the dtype of ``z``.
    """
    return np.sqrt(z)


def kexp(z):
    """Exponential of a real or complex argument.

    Parameters
    ----------
    z : float or complex

    Returns
    -------
    float or complex
    """
    return np.exp(z)


def klog(z):
    """Natural logarithm of a real or complex argument.

    Every caller in this package floors the argument strictly positive on the real axis,
    so the complex branch never approaches the cut on ``(-inf, 0]``.

    Parameters
    ----------
    z : float or complex

    Returns
    -------
    float or complex
    """
    return np.log(z)


def kreal(z):
    """Real part of a real or complex argument.

    Numpy reads ``.real`` off either, so this is a pass-through here.  C cannot: the real
    part of a ``double`` is not spelled the same way as that of a ``double complex``, so
    the compiled twin resolves it per specialization.

    Parameters
    ----------
    z : float or complex

    Returns
    -------
    float
    """
    return z.real


def kzeros(n, z):
    """A zeroed buffer of length ``n``, at the dtype of ``z``.

    Kernels that build a vector from the flow state need it to follow that state's dtype
    -- real while a residual is evaluated, complex while a Jacobian column is seeded.
    numpy can be told a dtype at run time and C cannot, so the compiled twin resolves the
    two cases at compile time instead.

    Parameters
    ----------
    n : int
        Length.
    z : float or complex
        A value at the wanted dtype; its value is not used.

    Returns
    -------
    ndarray
        ``n`` zeros, real or complex to match ``z``.
    """
    return np.zeros(n) + z * 0.0


def kview2(a, o, n0, n1):
    """A two-dimensional view of ``n0 * n1`` entries of ``a``, starting at ``o``.

    The packed thermochemistry bundle is one flat array of blocks, and the kernels read
    each block at its own shape.  Reshaping is free on an array and impossible on a typed
    buffer, so the compiled twin builds the view from the address instead.

    Parameters
    ----------
    a : ndarray
        The flat, contiguous array the block lies in.
    o : int
        Index of the block's first entry.
    n0, n1 : int
        The block's shape.  Both must be positive.

    Returns
    -------
    ndarray
        A ``(n0, n1)`` view, sharing ``a``'s memory.
    """
    return a[o : o + n0 * n1].reshape((n0, n1))


def kview3(a, o, n0, n1, n2):
    """A three-dimensional view of ``n0 * n1 * n2`` entries of ``a``, starting at ``o``.

    Parameters
    ----------
    a : ndarray
        The flat, contiguous array the block lies in.
    o : int
        Index of the block's first entry.
    n0, n1, n2 : int
        The block's shape.  All must be positive.

    Returns
    -------
    ndarray
        A ``(n0, n1, n2)`` view, sharing ``a``'s memory.

    See also
    --------
    kview2 : the two-dimensional case.
    """
    return a[o : o + n0 * n1 * n2].reshape((n0, n1, n2))


def kviewi(a, o, n):
    """``n`` whole numbers laid over ``a[o:o + n]``.

    A kernel that is handed its working space by its caller gets one buffer of one dtype,
    and needs several: a pivot vector is whole numbers, a phase-present flag is a byte.
    Reading a region back at another dtype is what saves the caller from passing an array
    per dtype, and costs nothing at either end -- the same bytes, read differently.

    A whole number is the width of a float here, so the region is ``n`` entries long.

    Parameters
    ----------
    a : ndarray
        The float buffer the region lies in.
    o : int
        Index of the region's first entry.
    n : int
        How many whole numbers are wanted.

    Returns
    -------
    ndarray
        An ``n``-long view of ``int64``, sharing ``a``'s memory.

    See also
    --------
    kviewb : the same for bytes.
    kscratch : the same for the working dtype of a kernel.
    """
    return a[o : o + n].view(np.int64)


def kviewb(a, o, n):
    """``n`` bytes laid over the float region at ``a[o:]``.

    Eight to a float, so the region a caller must reserve is ``(n + 7) // 8`` long.

    Parameters
    ----------
    a : ndarray
        The float buffer the region lies in.
    o : int
        Index of the region's first entry.
    n : int
        How many bytes are wanted.

    Returns
    -------
    ndarray
        An ``n``-long view of ``uint8``, sharing ``a``'s memory.
    """
    return a[o : o + (n + 7) // 8].view(np.uint8)[:n]


def kscratch(a, o, n, z):
    """``n`` working values at the dtype of ``z``, laid over the float region at ``a[o:]``.

    The kernels that carry a complex-step seed need their working space at the dtype of
    the state, and the caller who owns that space has only one buffer. A complex value is
    two floats wide, so the region to reserve is ``2 * n`` either way -- the real case
    uses half of it.

    Parameters
    ----------
    a : ndarray
        The float buffer the region lies in.
    o : int
        Index of the region's first entry.
    n : int
        How many working values are wanted.
    z : float or complex
        A value at the wanted dtype; its value is not used.

    Returns
    -------
    ndarray
        An ``n``-long view at ``z``'s dtype, sharing ``a``'s memory.
    """
    if np.iscomplexobj(z):
        return a[o : o + 2 * n].view(np.complex128)
    return a[o : o + n]


if BACKEND == "numba":
    # numba resolves the dtype at compile time instead, so each specialization returns its
    # own concrete type rather than a union the caller would have to unwrap.
    from numba import types
    from numba.extending import overload

    @overload(kscratch, inline="always")
    def _kscratch_ovl(a, o, n, z):
        if isinstance(z, types.Complex):

            def impl(a, o, n, z):
                return a[o : o + 2 * n].view(np.complex128)

            return impl

        def impl(a, o, n, z):
            return a[o : o + n]

        return impl


# Compiled with the kernels that call it, so a caller reaches a dispatcher rather than
# an interpreted function (see :func:`nefes._backend.jit_kernels`).  ``kscratch`` is
# deliberately absent: it is the base of the numba specialization above, and decorating it
# would hide that registration behind a dispatcher, leaving numba to compile a body whose
# two branches return different types.
jit_kernels(
    __name__,
    ("ksqrt", "kexp", "klog", "kreal", "kzeros", "kview2", "kview3", "kviewi", "kviewb"),
)
