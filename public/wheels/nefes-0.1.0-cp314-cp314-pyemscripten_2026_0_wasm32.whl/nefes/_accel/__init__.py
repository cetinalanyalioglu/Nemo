"""Ahead-of-time compiled kernels, built by NEFES_BUILD_ACCEL=1.

Generated: do not edit.  Each module here is compiled from the identically named
source under ``nefes`` and is imported in its place when the accel backend is
selected (see :mod:`nefes._backend`).
"""

MODULES = ['assembly.smooth', 'assembly.dense', 'thermo.perfect_gas', 'thermo.kernel', 'thermo.edge_state', 'thermo.api', 'assembly.closure', 'assembly.recover', 'elements.kernels', 'assembly.assemble']
