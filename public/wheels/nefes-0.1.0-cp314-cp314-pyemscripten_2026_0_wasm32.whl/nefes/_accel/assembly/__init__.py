"""Generated: compiled kernels."""
