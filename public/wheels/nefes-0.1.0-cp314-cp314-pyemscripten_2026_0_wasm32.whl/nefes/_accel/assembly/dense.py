"""Dense linear solve for the small systems inside the compiled kernels.

The reduced systems the equilibrium kernels build are tiny -- of order the number of
chemical elements -- and are rebuilt and solved once per Newton step.  At that size the
cost of reaching a library solver dominates the arithmetic, so they are factored here
instead: :func:`lu_factor` once, then :func:`lu_solve` per right-hand side, which also
lets a matrix carrying several right-hand sides be factored a single time.
:func:`lu_solve_copy` is the one-shot form for a matrix the caller still needs afterwards.

Both are dtype-generic, so one source serves the real residual and the ``complex128``
complex-step seed.  **The pivot is chosen on the real part**, which makes the pivot
sequence independent of an imaginary seed: the factorization is then a fixed sequence of
analytic operations on the seeded entries, and the complex step through it is exact.  A
library solver pivots on the full magnitude instead, where a seed could in principle
reorder two near-equal pivots and put a discontinuity in the middle of the derivative.

Singularity is reported as a return value rather than raised, so a kernel can re-seed and
retry inside its own Newton loop without an exception crossing the compiled boundary.

Public: :func:`lu_factor`, :func:`lu_solve`, :func:`lu_solve_copy`.
"""

import cython

from .._backend import jit_kernels

if not cython.compiled:  # a compiled build cimports these from _prim.pxd instead
    from ._prim import kreal

__all__ = ["lu_factor", "lu_solve", "lu_solve_copy"]


def lu_factor(A, piv):
    """Factor ``A`` in place into its LU factors with partial pivoting.

    Parameters
    ----------
    A : ndarray
        Square matrix ``(n, n)``, overwritten by the factors: ``U`` on and above the
        diagonal, the multipliers of ``L`` below it (its unit diagonal is implied).
    piv : ndarray
        Integer buffer of length ``n``, filled with the row interchanges.

    Returns
    -------
    bool
        ``False`` when a column is empty at the pivot, leaving the caller to re-seed
        rather than propagate a meaningless solve.

    See also
    --------
    lu_solve : apply the factors to a right-hand side.
    """
    n = A.shape[0]
    for c in range(n):
        # Partial pivot, located on the real part so an imaginary seed cannot reorder it.
        best = c
        big = abs(kreal(A[c, c]))
        for r in range(c + 1, n):
            v = abs(kreal(A[r, c]))
            if v > big:
                big = v
                best = r
        # Written as a positive test so a non-finite column fails here too, rather than
        # propagating a meaningless factorization: the caller's re-seed is the right answer
        # to both an empty pivot and a state that has already gone non-finite.
        if not (big > 0.0):
            return False
        piv[c] = best
        if best != c:
            for k in range(n):
                swap = A[c, k]
                A[c, k] = A[best, k]
                A[best, k] = swap
        inv = 1.0 / A[c, c]
        for r in range(c + 1, n):
            f = A[r, c] * inv
            A[r, c] = f
            for k in range(c + 1, n):
                A[r, k] -= f * A[c, k]
    return True


def lu_solve(A, piv, b, x):
    """Solve ``A x = b`` from the factors :func:`lu_factor` produced.

    Parameters
    ----------
    A, piv : ndarray
        The factored matrix and its row interchanges.
    b : ndarray
        Right-hand side of length ``n``, consumed (overwritten by the forward
        substitution); pass a copy when the original is still needed.
    x : ndarray
        Output buffer of length ``n``, receiving the solution.  Passing ``b`` itself is
        allowed: back substitution reads ``b[r]`` before writing ``x[r]``.

    See also
    --------
    lu_factor : produce the factors.
    """
    n = A.shape[0]
    # Every interchange first.  A swap during factorization also moves the multipliers already
    # stored to the left of the pivot column, so the factors satisfy ``P A = L U`` for the whole
    # permutation -- applying the interchanges one at a time between elimination steps would
    # solve a different system.
    for c in range(n):
        p = piv[c]
        if p != c:
            swap = b[c]
            b[c] = b[p]
            b[p] = swap
    for c in range(n):  # forward substitution: L y = P b
        for r in range(c + 1, n):
            b[r] -= A[r, c] * b[c]
    for r in range(n - 1, -1, -1):  # back substitution: U x = y
        acc = b[r]
        for k in range(r + 1, n):
            acc -= A[r, k] * x[k]
        x[r] = acc / A[r, r]


def lu_solve_copy(A, b, work, piv, x):
    """Solve ``A x = b`` leaving ``A`` and ``b`` untouched.

    Parameters
    ----------
    A : ndarray
        Square matrix ``(n, n)``, read only.
    b : ndarray
        Right-hand side of length ``n``, read only.
    work : ndarray
        Scratch ``(n, n)`` of ``A``'s dtype, receiving the factors.
    piv : ndarray
        Integer scratch of length ``n``.
    x : ndarray
        Output buffer of length ``n``; also carries the working right-hand side.

    Returns
    -------
    bool
        ``False`` on a singular column, as :func:`lu_factor`.
    """
    n = A.shape[0]
    for r in range(n):
        for c in range(n):
            work[r, c] = A[r, c]
    if not lu_factor(work, piv):
        return False
    for r in range(n):
        x[r] = b[r]
    lu_solve(work, piv, x, x)
    return True


# See :func:`nefes._backend.jit_kernels`: the definitions above stay undecorated so the
# ahead-of-time build can give them a C calling convention, and numba is applied here.
jit_kernels(__name__, ("lu_factor", "lu_solve", "lu_solve_copy"))
