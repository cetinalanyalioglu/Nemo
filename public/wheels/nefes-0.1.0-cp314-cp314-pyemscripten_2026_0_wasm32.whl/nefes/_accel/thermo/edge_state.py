"""Equilibrium / frozen edge-state producers: the network side of the thermochemistry.

A :class:`nefes.thermo.SpeciesSet` (the species *data* -- NASA polynomials and
the element matrix, all chemical equilibrium needs) is packed into the immutable
``(tf, ti)`` array bundle together with the network's **feed streams**.  A feed
stream is one distinct injected composition (an oxidizer, a diluent, a fuel,
...); the network transports one conserved band-1 scalar per stream -- the
**mixture fraction** ``xi_k`` -- and the closures reconstruct everything else by a
forward blend of ``xi`` (see :mod:`nefes.composition`).  The compiled kernels in
:mod:`nefes.thermo.kernel` unpack the flat arrays and run the element-potential
equilibrium solve, so all chemistry stays behind the single thermo boundary and
inside the network's ``@njit`` residual path.

Two per-edge models share one species_set + stream set:

* ``EQ_FROZEN`` -- the unburnt side: a frozen (non-reacting) real-gas state whose
  species moles are the **forward blend** ``n_feed = xi @ Nfeed`` of the feed
  streams.  No element inversion, no "element-distinguishable" restriction, so the
  unburnt composition can be any mixture of arbitrarily many co-injected fuels.
* ``EQ_KERNEL`` -- the burnt side: HP chemical equilibrium of the elemental
  composition ``Z = xi @ Zfeed`` over the product species -- gaseous first, then any
  high-temperature condensed products (e.g. graphite), which the kernel treats as pure
  phases at unit activity.

The kinetic-energy coupling is exact: the closures recover the static state at
``h = h_t - u^2/2``.  Because static ``p`` is the band-1 unknown, ``G(h) = h_t -
1/2 (mdot / (rho(h) A))^2 - h`` is strictly monotone in ``h``, so the ``ke``
wrappers (:func:`eq_kernel_state_ke_warm` and friends) take a safeguarded
bracketed root of ``G`` on the real part and splice the imaginary part by the
implicit-function theorem -- the same shape as the perfect-gas density root, no
caps or floors.

``tf`` layout (all float64, ``mol`` units throughout)::

    [ p_ref, T_init, T_init_frozen,
      coeffs(Ns*MI*9), Tint(Ns*(MI-1)), A(Ne*Ns), element_weights(Ne),
      Zfeed(K*Ne), Nfeed(K*Nf), feed_coeffs(Nf*MI*9), feed_Tint(Nf*(MI-1)),
      prod_A(Ne*Np), prod_coeffs(Np*MI*9), prod_Tint(Np*(MI-1)) ]

``ti = [Ne, Ns, MI, MI-1, Nf, K, Np, Ng]`` (``MI`` = max NASA intervals; ``Nf`` = feed-
species union; ``K`` = number of feed streams = transported mixture fractions; ``Np`` =
number of equilibrium product species, ordered gas-then-condensed; ``Ng`` = the gas count,
so products ``Ng..Np-1`` are the condensed phases).
"""

import cython
import numpy as np

from .._backend import BACKEND, jit_kernels
from ..chem.composition import stream_pack_arrays
from .kernel import (
    RU,
    _cs_scratch_len,
    equil_scratch_len,
    equil_state_cs,
    equilibrate_hp_cs,
    equilibrium_sound_speed,
    frozen_state_from_moles_cs,
)

if not cython.compiled:  # a compiled build cimports these instead
    from ..assembly._prim import kreal, kview2, kview3, kzeros
    from ..assembly.smooth import marker_gate

    _GATE = marker_gate
else:
    # Compiled, ``marker_gate`` is a name the compiler resolves rather than a value, and it
    # is generic: asked to pick a form for an argument whose type it cannot see, it picks the
    # complex one, and a real state comes back complex.  The one caller that is ordinary
    # Python therefore reaches the gate through the module, where the choice is made on the
    # argument itself.  Every other caller is compiled and hands it a typed marker.
    from ..assembly.smooth import marker_gate as _GATE

_OFF_BLOCKS = 3  # p_ref, T_init, T_init_frozen precede the flat data blocks

# Transition width of the burnt-marker blend gate (nefes.smooth.marker_gate).  Gentle (so the
# coupled solve stays Newton-friendly); the gate's zero-leak normalization makes the converged
# accuracy independent of it -- a frozen edge is pure frozen, a burnt edge pure equilibrium.
MARKER_GATE_WIDTH = 0.1

# Candidate-species count above which the automatic (CEA-style) product slate is reduced to
# its non-trace members before packing: past this the equilibrium Newton solve is expensive
# enough that reducing pays off (hydrocarbon/air admits ~115); below it, run the slate raw.
AUTO_REDUCE_THRESHOLD = 40

# Kinetic-energy density root (see _ke_root_real).
KE_ROOT_TOL = 1.0e-13  # relative step width at which the bracketed root is converged
KE_ROOT_MAX_STEPS = 100  # safeguarded secant steps allowed once a straddling pair is in hand
KE_BRACKET_MAX_DOUBLES = 200  # upward doublings allowed when bracketing from the quiescent density
# Offsets tried either side of a cached density when bracketing the root around it.  The first
# is at the convergence tolerance, so a seed that is already the root brackets it immediately;
# the rest sweep the neighbourhood geometrically out to about a quarter of the seed.  That
# ceiling is deliberate: past it a stale seed can straddle the *other* (dense, formally
# supersonic) root of ``F`` at high flux, and the quiescent bracket -- which starts below every
# root and walks up -- is the one that reliably picks the physical branch.
KE_WARM_PROBE = KE_ROOT_TOL
KE_WARM_COARSE = 1.0e-3
KE_WARM_GROWTH = 6.0
KE_WARM_TRIES = 5


def pack_equilibrium(lib, stream_Y, T_init=3000.0, T_init_frozen=300.0):
    """Pack a ``nefes.thermo.SpeciesSet`` + its feed streams into ``(tf, ti)``.

    ``stream_Y`` is ``(K, n_species)`` mass fractions, one row per distinct feed
    stream (:func:`nefes.composition.build_streams`).  ``K = 0`` packs a stream-less
    bundle -- valid for the standalone equilibrium kernel
    (:func:`eq_kernel_state_from_Z`) but not for an ``EQ_FROZEN`` edge, which needs
    streams to reconstruct from.  ``lib`` may be a ``SpeciesSet`` or a
    ``Mechanism`` (which proxies the same data surface).
    """
    coeffs, Tint = lib.nasa9_arrays()  # (Ns, MI, 9), (Ns, MI-1)
    Ne = lib.n_elements
    Ns = lib.n_species
    MI = coeffs.shape[1]
    MIm1 = Tint.shape[1]
    A = np.ascontiguousarray(lib.element_matrix, dtype=np.float64)  # (Ne, Ns)
    ew = np.ascontiguousarray(lib.element_weights, dtype=np.float64)  # (Ne,) kg/mol

    stream_Y = np.atleast_2d(np.asarray(stream_Y, dtype=np.float64)) if np.size(stream_Y) else np.zeros((0, Ns))
    K = stream_Y.shape[0]
    feed_idx, Nfeed, Zfeed = stream_pack_arrays(lib, stream_Y)  # (Nf,), (K, Nf), (K, Ne)
    Nf = feed_idx.shape[0]
    feed_coeffs = np.ascontiguousarray(coeffs[feed_idx], dtype=np.float64)  # (Nf, MI, 9)
    feed_Tint = np.ascontiguousarray(Tint[feed_idx], dtype=np.float64)  # (Nf, MI-1)

    # Product subset for the HP-equilibrium (burnt) kernel.  Gaseous products come first, then
    # any condensed products (a high-temperature phase such as graphite), so the kernel splits
    # them by a single count ``Ng``: gas species carry the mole-fraction/pressure potential
    # while condensed products are pure phases at unit activity.  Condensed *feed* species (e.g.
    # liquid fuel) stay in the full arrays for the frozen reconstruction but are not products.
    prod_mask = np.asarray(getattr(lib, "product_mask", np.ones(Ns, bool)), dtype=bool)
    phase = np.asarray(getattr(lib, "species_phase", np.zeros(Ns, dtype=np.int64)), dtype=np.int64)
    gas_prod = [j for j in range(Ns) if prod_mask[j] and phase[j] == 0]
    cond_prod = [j for j in range(Ns) if prod_mask[j] and phase[j] != 0]
    prod_idx = np.array(gas_prod + cond_prod, dtype=np.int64)
    Ng = len(gas_prod)
    Np = prod_idx.shape[0]
    prod_A = np.ascontiguousarray(A[:, prod_idx], dtype=np.float64)  # (Ne, Np)
    prod_coeffs = np.ascontiguousarray(coeffs[prod_idx], dtype=np.float64)  # (Np, MI, 9)
    prod_Tint = np.ascontiguousarray(Tint[prod_idx], dtype=np.float64)  # (Np, MI-1)

    header = np.array([lib.P_ref, T_init, T_init_frozen], dtype=np.float64)
    tf = np.concatenate(
        [
            header,
            coeffs.ravel(),
            Tint.ravel(),
            A.ravel(),
            ew,
            np.ascontiguousarray(Zfeed, dtype=np.float64).ravel(),
            np.ascontiguousarray(Nfeed, dtype=np.float64).ravel(),
            feed_coeffs.ravel(),
            feed_Tint.ravel(),
            prod_A.ravel(),
            prod_coeffs.ravel(),
            prod_Tint.ravel(),
        ]
    ).astype(np.float64)
    ti = np.array([Ne, Ns, MI, MIm1, Nf, K, Np, Ng], dtype=np.int64)
    return np.ascontiguousarray(tf), np.ascontiguousarray(ti)


def _product_blocks(tf, ti):
    """Slice the product subset ``(prod_coeffs, prod_Tint, prod_A, ew)`` from a bundle.

    The burnt HP-equilibrium kernel solves over these ``Np`` product species (gaseous first,
    then condensed products; ``ti[7] = Ng`` is the gas count), not the full species_set -- so a
    condensed *feed* species never enters the product set.
    """
    Ne = ti[0]
    Ns = ti[1]
    MI = ti[2]
    MIm1 = ti[3]
    Nf = ti[4]
    K = ti[5]
    Np = ti[6]
    # element weights sit right after the full A block (used to map Z -> gram-atoms b0)
    o_ew = _OFF_BLOCKS + Ns * MI * 9 + Ns * MIm1 + Ne * Ns
    ew = tf[o_ew : o_ew + Ne]
    # product blocks are appended after Zfeed, Nfeed, feed_coeffs, feed_Tint
    o = o_ew + Ne + K * Ne + K * Nf + Nf * MI * 9 + Nf * MIm1
    prod_A = kview2(tf, o, Ne, Np)
    o += Ne * Np
    prod_coeffs = kview3(tf, o, Np, MI, 9)
    o += Np * MI * 9
    prod_Tint = kview2(tf, o, Np, MIm1)
    return prod_coeffs, prod_Tint, prod_A, ew


def _feed_blocks(tf, ti):
    """Slice the feed subset ``(Nfeed, feed_coeffs, feed_Tint)`` from a bundle.

    ``Nfeed`` is ``(K, Nf)``: the species moles per kg of each of the ``K`` feed
    streams over the ``Nf`` feed-species union.  The unburnt composition of a frozen
    edge is the forward blend ``n_feed = xi @ Nfeed`` of its transported mixture
    fractions -- the reconstruction :func:`eq_frozen_state` runs.
    """
    Ne = ti[0]
    Ns = ti[1]
    MI = ti[2]
    MIm1 = ti[3]
    Nf = ti[4]
    K = ti[5]
    # feed blocks sit after the full coeffs/Tint/A/element-weight/Zfeed blocks
    o = _OFF_BLOCKS + Ns * MI * 9 + Ns * MIm1 + Ne * Ns + Ne + K * Ne
    Nfeed = kview2(tf, o, K, Nf)
    o += K * Nf
    feed_coeffs = kview3(tf, o, Nf, MI, 9)
    o += Nf * MI * 9
    feed_Tint = kview2(tf, o, Nf, MIm1)
    return Nfeed, feed_coeffs, feed_Tint


def eq_kernel_state_from_Z(tf, ti, Z_el, h, p):
    """HP-equilibrium state ``(T, rho, c_eq, W)`` for an explicit elemental ``Z_el``.

    The stream-free entry point: ``Z_el`` is the gram-fraction elemental vector
    directly (used by the kernel consistency tests).  The network calls
    :func:`eq_kernel_state`, which maps the transported mixture fractions to ``Z``.
    """
    Ne = ti[0]
    Np = ti[6]
    ng = ti[7]
    p_ref = tf[0]
    T_init = tf[1]
    coeffs, Tint, Af, ew = _product_blocks(tf, ti)
    b0 = kzeros(Ne, Z_el[0])
    sb = 0.0
    for i in range(Ne):
        b0[i] = Z_el[i] / ew[i]
        sb += kreal(b0[i])
    nj_init = kzeros(Np, 0.0)
    for j in range(ng):
        nj_init[j] = sb / (2.0 * ng)  # gas products seeded uniformly
    # condensed products start absent (admitted by the phase test), which is how they arrive
    # flag/nit are the solver's convergence diagnostics; unused on this path
    # No caller-owned working space on this path: it is the stream-free entry point, called
    # once rather than per edge per Newton step, so the allocations do not signify.  Spelled
    # as an empty slice rather than an empty buffer, which is not a thing a compiled build
    # can allocate.
    T, rho, c, ntot, _flag, _nit = equil_state_cs(coeffs, Tint, Af, b0, h, p, p_ref, T_init, ng, nj_init, tf[0:0])
    return T, rho, c, 1.0 / ntot


def eq_kernel_state_from_Z_warm(tf, ti, Z_el, h, p, cache):
    """HP-equilibrium state ``(T, rho, c_eq, W)``, warm-started from ``cache``.

    Identical to :func:`eq_kernel_state_from_Z`, but the element-potential Newton seeds
    from the per-edge ``cache`` -- whose first ``Np + 1`` slots hold the last converged
    moles (``cache[:Np]``) and temperature (``cache[Np]``) -- and writes the new converged
    pair back, so a nearby re-solve (the next Newton iterate, or a complex-step Jacobian
    column whose real part is unchanged) converges in a couple of steps.  **Both** the
    composition and the temperature must be warm-started together; seeding the composition
    at a stale ``T_init`` leaves the first step badly inconsistent.  ``cache`` is purely a
    *speed* hint: the HP equilibrium is unique, so the converged state is independent of it.
    An empty / mis-sized ``cache`` (e.g. a perfect-gas placeholder) disables the warm start
    and falls back to the uniform composition guess at ``T_init``.
    """
    Ne = ti[0]
    Np = ti[6]
    ng = ti[7]
    p_ref = tf[0]
    T_init = tf[1]
    coeffs, Tint, Af, ew = _product_blocks(tf, ti)
    b0 = kzeros(Ne, Z_el[0])

    # Default: gas products at the robust uniform guess, condensed products absent.
    sb = 0.0
    for i in range(Ne):
        b0[i] = Z_el[i] / ew[i]
        sb += kreal(b0[i])
    nj_init = kzeros(Np, 0.0)
    for j in range(ng):
        nj_init[j] = sb / (2.0 * ng)
    T_start = T_init
    has_cache = cache.shape[0] >= Np + 1  # wider caches carry the density seeds after these slots
    if has_cache and cache[Np] > 0.0:  # a populated cache: warm-start composition *and* temperature
        T_start = cache[Np]
        for j in range(Np):
            if cache[j] > 0.0:
                nj_init[j] = cache[j]  # exactly-zero (underflowed) species keep the uniform guess

    # Working space for the solve, taken from the tail of the same cache: it is the
    # caller's, allocated once for a whole assembly pass, so nothing below here reaches for
    # an array of its own.  A cache too narrow to hold it (an older layout, or the
    # perfect-gas placeholder) leaves each routine allocating exactly as it did.
    cut = Np + 3
    span = equil_scratch_len(Np, Ne, ng)
    if cache.shape[0] >= cut + span:
        cs_scr = cache[cut : cut + _cs_scratch_len(Np, Ne, ng)]
        snd_scr = cache[cut + _cs_scratch_len(Np, Ne, ng) : cut + span]
    else:
        cs_scr = cache[0:0]
        snd_scr = cache[0:0]

    # flag/nit are the solver's convergence diagnostics; unused on this path
    T, nj, ntot, _flag, _nit = equilibrate_hp_cs(coeffs, Tint, Af, b0, h, p, p_ref, T_start, ng, nj_init, cs_scr)
    rho = p / (RU * ntot * T)
    c = equilibrium_sound_speed(coeffs, Tint, Af, nj, ntot, T, p, ng, snd_scr)
    if has_cache:  # store the converged (real) composition + temperature for the next solve
        for j in range(Np):
            cache[j] = kreal(nj[j])
        cache[Np] = kreal(T)
    return T, rho, c, 1.0 / ntot


def eq_kernel_state_warm(tf, ti, xi, h, p, cache):
    """Warm-started :func:`eq_kernel_state`: maps ``xi`` to ``Z`` then seeds from ``cache``."""
    Z = _xi_to_Z(tf, ti, xi)
    return eq_kernel_state_from_Z_warm(tf, ti, Z, h, p, cache)


def _xi_to_Z(tf, ti, xi):
    """Elemental ``Z = xi @ Zfeed`` from the transported mixture fractions (linear)."""
    Ne = ti[0]
    Ns = ti[1]
    MI = ti[2]
    MIm1 = ti[3]
    K = ti[5]
    o = _OFF_BLOCKS + Ns * MI * 9 + Ns * MIm1 + Ne * Ns + Ne  # skip coeffs, Tint, A, ew
    Zfeed = kview2(tf, o, K, Ne)
    Z = kzeros(Ne, xi[0])
    for i in range(Ne):
        acc = xi[0] * 0.0
        for k in range(K):
            acc = acc + xi[k] * Zfeed[k, i]
        Z[i] = acc
    return Z


def eq_kernel_state(tf, ti, xi, h, p):
    """HP-equilibrium state ``(T, rho, c_eq, W)`` for transported mixture fractions ``xi``.

    Maps ``xi`` to the elemental composition (a linear, complex-analytic blend of
    the feed streams) and delegates to :func:`eq_kernel_state_from_Z`.
    """
    Z = _xi_to_Z(tf, ti, xi)
    return eq_kernel_state_from_Z(tf, ti, Z, h, p)


def eq_frozen_state(tf, ti, xi, h, p):
    """Frozen real-gas state ``(T, rho, c_frozen, W)`` of the unburnt mixture ``xi``.

    The unburnt species moles are the forward blend ``n_feed = xi @ Nfeed`` of the
    feed streams (no element inversion); the temperature follows from ``h``.
    """
    Nf = ti[4]
    K = ti[5]
    T_init_fr = tf[2]
    Nfeed, feed_coeffs, feed_Tint = _feed_blocks(tf, ti)

    n_feed = kzeros(Nf, xi[0])
    for f in range(Nf):
        acc = xi[0] * 0.0
        for k in range(K):
            acc = acc + xi[k] * Nfeed[k, f]
        n_feed[f] = acc

    T, rho, c, ntot = frozen_state_from_moles_cs(feed_coeffs, feed_Tint, n_feed, h, p, T_init_fr)
    return T, rho, c, 1.0 / ntot


def eq_marker_state(tf, ti, xi, marker, h, p):
    """Marker-gated blend of the frozen and equilibrium states ``(T, rho, c, W)``.

    Runs **both** closures at the transported point ``(xi, h, p)`` and blends each recovered
    field by ``g = marker_gate(marker)``::

        field = (1 - g) * frozen + g * equilibrium

    ``g(0) = 0`` (pure frozen / unburnt) and ``g(1) = 1`` (pure equilibrium / burnt) exactly, so
    the blend is only active in transients (the marker is bimodal at convergence).  The same
    ``h_t`` is a valid enthalpy for *both* compositions -- the unburnt reactant inverts to its
    cold ``T``, the burnt mixture to the flame ``T`` -- so both solves always converge and the
    gate selects the physical one.  Complex-step-safe (smooth gate, complex-analytic closures).
    """
    Tf, rf, cf, Wf = eq_frozen_state(tf, ti, xi, h, p)
    Te, re, ce, We = eq_kernel_state(tf, ti, xi, h, p)
    g = marker_gate(marker, MARKER_GATE_WIDTH)
    return (1.0 - g) * Tf + g * Te, (1.0 - g) * rf + g * re, (1.0 - g) * cf + g * ce, (1.0 - g) * Wf + g * We


def eq_marker_state_warm(tf, ti, xi, marker, h, p, cache):
    """Warm-started :func:`eq_marker_state`: the equilibrium leg seeds from ``cache``.

    Identical to :func:`eq_marker_state`, but the (dominant-cost) burnt equilibrium solve is
    warm-started from the per-edge ``cache`` (moles + temperature).  The frozen leg needs no
    cache.  The equilibrium kernel runs on **every** marker-gated edge regardless of ``marker``
    (its blend weight may be ~0), so the cache stays populated and the burnt product moles are
    available for post-processing on any reacting edge.
    """
    Tf, rf, cf, Wf = eq_frozen_state(tf, ti, xi, h, p)
    Te, re, ce, We = eq_kernel_state_warm(tf, ti, xi, h, p, cache)
    g = marker_gate(marker, MARKER_GATE_WIDTH)
    return (1.0 - g) * Tf + g * Te, (1.0 - g) * rf + g * re, (1.0 - g) * cf + g * ce, (1.0 - g) * Wf + g * We


def eq_total_pressure(M, p, T, c, W):
    """Isentropic total pressure for a variable-gamma gas (gamma = c^2 W / (R_u T))."""
    gamma = c * c * W / (RU * T)
    return p * (1.0 + 0.5 * (gamma - 1.0) * M * M) ** (gamma / (gamma - 1.0))


# ---------------------------------------------------------------------------
# Kinetic-energy coupling for the reacting closures
# ---------------------------------------------------------------------------
# The ``ke`` wrappers solve the outer static-enthalpy root ``h = h_t - u^2/2``
# described in the module docstring.  ``frozen`` selects the inner closure
# (0 = HP equilibrium / burnt, 1 = frozen / unburnt) so the same machinery serves
# both legs; the marker blend runs the two separately, each with its own density
# and hence its own ``u`` and ``h``.


def _ke_inner_state(frozen, tf, ti, xi, h, p, cache):
    """Static reacting state ``(T, rho, c, W)`` at ``(xi, h, p)`` for the selected leg."""
    if frozen == 0:
        return eq_kernel_state_warm(tf, ti, xi, h, p, cache)
    return eq_frozen_state(tf, ti, xi, h, p)


def _ke_secant(frozen, tf, ti, xi_r, k, p_r, ht_r, cache, a, fa, b, fb):
    """Density root of ``F`` from a straddling pair ``F(a) < 0 <= F(b)``.

    A secant step on the pair, bisecting whenever the secant would leave the bracket, so
    the iterate can never escape it.  Shared by both entries of :func:`_ke_root_real` --
    the bracket differs, the refinement does not.
    """
    rho = 0.5 * (a + b)
    for _ in range(KE_ROOT_MAX_STEPS):
        h = ht_r - k / (rho * rho)
        f = rho - _ke_inner_state(frozen, tf, ti, xi_r, h, p_r, cache)[1]
        if f < 0.0:
            a = rho
            fa = f
        else:
            b = rho
            fb = f
        rho_new = a - fa * (b - a) / (fb - fa)  # secant from the straddling pair
        if not (a < rho_new < b):
            rho_new = 0.5 * (a + b)
        if abs(rho_new - rho) <= KE_ROOT_TOL * (abs(rho) + 1.0):
            return rho_new
        rho = rho_new
    return rho


def _ke_root_real(frozen, tf, ti, xi_r, mdot_r, p_r, ht_r, area_r, cache):
    """Real static enthalpy ``h_s = h_t - 1/2 (mdot/(rho A))^2`` from the density root.

    Recovers the static state by solving for **density**, mirroring the perfect-gas path
    (:func:`nefes.thermo.perfect_gas.pg_solve_density`) rather than searching in enthalpy.  With
    ``k = 1/2 (mdot/A)^2`` the residual is

    .. code-block:: text

        F(rho) = rho - rho_eq(h_t - k/rho^2, p),

    where ``rho_eq(h, p)`` is the closure density at static enthalpy ``h``.  ``F`` is strictly
    increasing (a denser state is colder, so the closure predicts a still-denser state, but more
    slowly than ``rho`` itself grows) with ``F -> +inf`` as ``rho -> inf`` and ``F < 0`` at the
    zero-velocity density, so the subsonic root **always exists and always brackets** -- the
    recovery cannot fail on a bad iterate (an over-flux iterate simply yields a dense, formally
    supersonic state that the choking complementarity resolves elsewhere).  The returned static
    enthalpy leaves the downstream state recovery and complex-step attachment unchanged.  All
    inputs are real parts.

    Each inner evaluation of ``F`` is a full closure solve, so the bracket is where the cost
    is.  When ``cache`` carries this leg's converged density from a previous solve, the bracket
    is opened around it instead of at the quiescent density: a nearby re-solve (the next Newton
    iterate, or a complex-step Jacobian column whose real part is unchanged) then straddles the
    root on the first offset and converges immediately.  A seed too far off to straddle within
    :data:`KE_WARM_TRIES` falls through to the quiescent bracket.  Like the composition warm
    start this is purely a *speed* hint -- the root is unique and the bracket is safeguarded
    either way, so the converged density does not depend on it.
    """
    flux = mdot_r / area_r
    k = 0.5 * flux * flux  # kinetic energy = k / rho^2

    # This leg's converged density from the previous solve (the frozen and equilibrium legs of a
    # marker-gated edge hold their own, since each solves its own root at its own density).
    slot = ti[6] + 1 + frozen
    if cache.shape[0] > slot and cache[slot] > 0.0:
        rho_seed = cache[slot]
        h = ht_r - k / (rho_seed * rho_seed)
        f_seed = rho_seed - _ke_inner_state(frozen, tf, ti, xi_r, h, p_r, cache)[1]
        # Step off the seed on the side the root must lie, widening until the pair straddles.
        step = KE_WARM_PROBE
        for attempt in range(KE_WARM_TRIES):
            if f_seed >= 0.0:  # root at or below the seed
                b = rho_seed
                fb = f_seed
                a = rho_seed / (1.0 + step)
                h = ht_r - k / (a * a)
                fa = a - _ke_inner_state(frozen, tf, ti, xi_r, h, p_r, cache)[1]
            else:  # root above the seed
                a = rho_seed
                fa = f_seed
                b = rho_seed * (1.0 + step)
                h = ht_r - k / (b * b)
                fb = b - _ke_inner_state(frozen, tf, ti, xi_r, h, p_r, cache)[1]
            if fa < 0.0 <= fb:
                if b - a <= KE_ROOT_TOL * (a + 1.0):  # already pinned to tolerance
                    rho = 0.5 * (a + b)
                else:
                    rho = _ke_secant(frozen, tf, ti, xi_r, k, p_r, ht_r, cache, a, fa, b, fb)
                cache[slot] = rho
                return ht_r - k / (rho * rho)
            step = KE_WARM_COARSE if attempt == 0 else step * KE_WARM_GROWTH

    # Zero-velocity density (all total enthalpy is static): the lower bracket.
    rho_lo = _ke_inner_state(frozen, tf, ti, xi_r, ht_r, p_r, cache)[1]
    if k / (rho_lo * rho_lo) <= 1e-300:  # quiescent / vanishing flux: h_s = h_t
        return ht_r

    # F(rho_lo) < 0: the implied static state h_t - k/rho_lo^2 is colder, hence denser than rho_lo.
    h = ht_r - k / (rho_lo * rho_lo)
    f_lo = rho_lo - _ke_inner_state(frozen, tf, ti, xi_r, h, p_r, cache)[1]
    if f_lo >= 0.0:  # degenerate closure response; fall back to the quiescent state
        return ht_r

    # Expand the upper bracket until F > 0 (guaranteed: F -> +inf as rho -> inf).
    rho_hi = 2.0 * rho_lo
    fb = 0.0
    bracketed = False
    for _ in range(KE_BRACKET_MAX_DOUBLES):
        h = ht_r - k / (rho_hi * rho_hi)
        fb = rho_hi - _ke_inner_state(frozen, tf, ti, xi_r, h, p_r, cache)[1]
        if fb > 0.0:
            bracketed = True
            break
        rho_hi *= 2.0
    if not bracketed:
        raise ValueError("kinetic-energy density bracket expansion failed")

    rho = _ke_secant(frozen, tf, ti, xi_r, k, p_r, ht_r, cache, rho_lo, f_lo, rho_hi, fb)
    if cache.shape[0] > slot:
        cache[slot] = rho
    return ht_r - k / (rho * rho)


def _ke_state_complex(frozen, tf, ti, xi, mdot, p, ht, area, cache, h_s):
    """Static state at ``h_s`` carrying the root's imaginary response to every seed.

    The kinetic-energy root ``G(h) = h_t - 1/2 (mdot/(rho(h) A))^2 - h`` is solved on the
    real parts alone, so the converged ``h_s`` arrives with no imaginary part.  This
    recovers it by the implicit function theorem: ``dG/dh`` comes from a complex step on
    the static enthalpy, the seed contribution ``Im(G)`` from evaluating ``G`` at the fixed
    real root with the inputs' own seeds in place, and ``Im(h_s) = -Im(G) / (dG/dh)``.
    The state is then recovered once more at the completed complex ``h_s``.

    Every backend calls this, so the mathematics of the splice exists once however the
    dtype dispatch around it is spelled.  All inputs but ``h_s`` may carry seeds.
    """
    p_r = kreal(p)
    area_r = kreal(area)
    mdot_r = kreal(mdot)
    # Two complex copies of the composition: one carrying its seed, one with it stripped.
    # Built rather than cast, since a typed buffer has no ``astype``.  The wanted dtype is
    # named by a literal rather than taken from ``xi``, which reaches here real whenever the
    # seed sits on one of the scalars.
    n_xi = xi.shape[0]
    xc = kzeros(n_xi, 0j)
    xr = kzeros(n_xi, 0j)
    for i in range(n_xi):
        xc[i] = xi[i]
        xr[i] = xc[i].real
    # d rho / d h at the converged point (complex step on the static enthalpy)
    eps = 1e-30
    inner_h = _ke_inner_state(frozen, tf, ti, xr, complex(h_s, eps), complex(p_r, 0.0), cache)[1]
    rho_h = inner_h.imag / eps
    rho_r = kreal(inner_h)
    gp = (mdot_r * mdot_r / (rho_r * rho_r * rho_r * area_r * area_r)) * rho_h - 1.0
    # input-seed contribution to G at the fixed real root (rho carries the p / xi seeds)
    rho0 = _ke_inner_state(frozen, tf, ti, xc, complex(h_s, 0.0), p, cache)[1]
    u0 = mdot / (rho0 * area)
    g0 = ht - 0.5 * u0 * u0 - h_s
    im_hs = -g0.imag / gp
    return _ke_inner_state(frozen, tf, ti, xc, complex(h_s, im_hs), p, cache)


def _attach_ke_state(frozen, tf, ti, xi, mdot, p, ht, area, cache, h_s):
    """Recover ``(T, rho, c, W)`` at the converged static enthalpy ``h_s`` (dtype-dispatched).

    Real inputs give the bare static state at ``h_s``; a complex-step seed on any input
    gives that state plus the implicit-function imaginary part of ``h_s`` with respect to
    it, so the recovered fields carry the exact seed.  The choice is made on the argument
    *types*, never on the flow state, so the result stays complex-analytic.
    """
    if (
        np.iscomplexobj(np.asarray(xi))
        or np.iscomplexobj(mdot)
        or np.iscomplexobj(p)
        or np.iscomplexobj(ht)
        or np.iscomplexobj(area)
    ):
        return _KE_SEEDED(frozen, tf, ti, xi, mdot, p, ht, area, cache, h_s)
    return _KE_PLAIN(frozen, tf, ti, xi, h_s, p, cache)


if not cython.compiled and BACKEND == "numba":
    # numba resolves the dtype dispatch of the base bodies at compile time instead,
    # so each specialization is branch-free and returns its own concrete type.
    from numba import types
    from numba.extending import overload

    @overload(_attach_ke_state, inline="always")
    def _attach_ke_state_ovl(frozen, tf, ti, xi, mdot, p, ht, area, cache, h_s):
        xi_complex = getattr(xi, "dtype", None) is not None and isinstance(xi.dtype, types.Complex)
        any_complex = (
            xi_complex
            or isinstance(mdot, types.Complex)
            or isinstance(p, types.Complex)
            or isinstance(ht, types.Complex)
            or isinstance(area, types.Complex)
        )
        if any_complex:

            def impl(frozen, tf, ti, xi, mdot, p, ht, area, cache, h_s):
                return _ke_state_complex(frozen, tf, ti, xi, mdot, p, ht, area, cache, h_s)

            return impl

        def impl(frozen, tf, ti, xi, mdot, p, ht, area, cache, h_s):
            return _ke_inner_state(frozen, tf, ti, xi, h_s, p, cache)

        return impl


def _ke_solve(frozen, tf, ti, xi, mdot, p, ht, area, cache):
    """KE-coupled reacting state ``(T, rho, c, W)``; dtype-generic, complex-step-safe."""
    # The composition arrives as a column of the solve state, a row apart; everything
    # below wants it contiguous, so it is made so once here rather than at each step.
    xi = np.ascontiguousarray(xi)
    xi_r = np.empty(xi.shape[0])
    for i in range(xi.shape[0]):
        xi_r[i] = kreal(xi[i])
    h_s = _ke_root_real(frozen, tf, ti, xi_r, kreal(mdot), kreal(p), kreal(ht), kreal(area), cache)
    return _attach_ke_state(frozen, tf, ti, xi, mdot, p, ht, area, cache, h_s)


def eq_kernel_state_ke_warm(tf, ti, xi, mdot, p, ht, area, cache):
    """Burnt (HP-equilibrium) state with the kinetic-energy coupling ``h = h_t - u^2/2``.

    Warm-started from ``cache`` (moles + temperature); the outer KE root reuses it on
    every inner evaluation so the bracketed solve stays cheap.
    """
    return _ke_solve(0, tf, ti, xi, mdot, p, ht, area, cache)


def eq_frozen_state_ke(tf, ti, xi, mdot, p, ht, area, cache):
    """Unburnt (frozen) state with the kinetic-energy coupling ``h = h_t - u^2/2``.

    The frozen closure needs no composition warm start, but the outer kinetic-energy root
    does: ``cache`` supplies and receives this leg's converged density (see
    :func:`_ke_root_real`).
    """
    return _ke_solve(1, tf, ti, xi, mdot, p, ht, area, cache)


def eq_marker_state_ke_warm(tf, ti, xi, marker, mdot, p, ht, area, cache):
    """Marker-gated blend of the KE-coupled frozen and equilibrium states.

    Each leg solves its **own** kinetic-energy root (its own density, hence its own
    ``u`` and static enthalpy), so the weighted-out leg always sits at a physical
    state -- the frozen leg never inherits the burnt edge's large kinetic energy.
    """
    Tf, rf, cf, Wf = _ke_solve(1, tf, ti, xi, mdot, p, ht, area, cache)
    Te, re, ce, We = _ke_solve(0, tf, ti, xi, mdot, p, ht, area, cache)
    g = _GATE(marker, MARKER_GATE_WIDTH)
    return (1.0 - g) * Tf + g * Te, (1.0 - g) * rf + g * re, (1.0 - g) * cf + g * ce, (1.0 - g) * Wf + g * We


# See :func:`nefes._backend.jit_kernels`.  ``_attach_ke_state`` is absent: it is the base
# of a numba specialization, and decorating it would hide that registration.
jit_kernels(
    __name__,
    (
        "_product_blocks",
        "_feed_blocks",
        "eq_kernel_state_from_Z",
        "eq_kernel_state_from_Z_warm",
        "eq_kernel_state_warm",
        "_xi_to_Z",
        "eq_kernel_state",
        "eq_frozen_state",
        "eq_marker_state",
        "eq_marker_state_warm",
        "eq_total_pressure",
        "_ke_inner_state",
        "_ke_secant",
        "_ke_root_real",
        "_ke_state_complex",
        "_ke_solve",
        "eq_kernel_state_ke_warm",
        "eq_frozen_state_ke",
        "eq_marker_state_ke_warm",
    ),
)

# ``_attach_ke_state`` picks between two kernels that take different argument types, which
# no single call can express once the module is compiled.  Reaching them through these
# names keeps that one call generic, and binding the names after the decoration above is
# what makes them the compiled forms rather than the bodies.
_KE_SEEDED = _ke_state_complex
_KE_PLAIN = _ke_inner_state

if cython.compiled:
    # The gate width is a C constant when compiled, and a C constant cannot be read from
    # outside the module.  Publishing it again keeps it importable, as it is elsewhere.
    globals()["MARKER_GATE_WIDTH"] = MARKER_GATE_WIDTH
