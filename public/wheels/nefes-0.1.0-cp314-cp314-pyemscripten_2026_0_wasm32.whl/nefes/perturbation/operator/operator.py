"""The acoustic operator ``A(omega) = J_alg + i*omega*M + P(omega) + S(omega)``.

The four blocks are the converged mean-flow Jacobian ``J_alg`` (the zero-frequency
operator, reused verbatim from the complex-step machinery), the storage block ``M``
(cavity/inline compliance and inertance), the duct phase propagation ``P(omega)``, and
the dynamic-source feedback ``S(omega)`` of a flame or mass source.  Each has its
producing elements and its stamp in ``stamps.py``.  All four ride a fixed-pattern fast
path: the storage and source contributions accumulate onto their slots per ``omega`` and
the duct phases overwrite theirs, so ``A(omega)`` is assembled in full with no slow-path
fallback.

Public: :class:`AcousticBlocks`, :func:`build_acoustic_blocks`, :func:`assemble_acoustic`.
"""

from dataclasses import dataclass, field
from typing import List

import numpy as np
import scipy.sparse as sp

from ...assembly.assemble import jacobian
from ...solver.report import states_table
from .stamps import (
    DuctStamp,
    _terminal_closure,
    _tm_block,
    build_duct_stamps,
    build_source_stamps,
    build_storage,
    build_tm_stamps,
    heat_addition_edges,
    stamp_boundaries,
    stamp_isentropic,
    stamp_propagation,
    stamp_sources,
    stamp_transfer_matrix,
)
from .terminals import find_terminals

# Generic non-zero frequency used to capture the (omega-independent) sparsity pattern.
_PLAN_OMEGA = 1.0

# Admissible values of the ``convected`` control: which convected wave families remain live.
CONVECTED_CHOICES = ("all", "entropy", "composition", "none")


def resolve_convected(isentropic, convected):
    """Resolve the wave controls to ``(pin_entropy, freeze_composition)``.

    ``convected`` names the convected families that remain **live**: ``"all"`` (both, the
    full operator), ``"entropy"`` (entropy convects, composition frozen), ``"composition"``
    (composition convects, entropy pinned), ``"none"`` (both removed -- identical to
    ``isentropic=True``).  ``isentropic=True`` is the established shorthand for ``"none"``
    and may not be combined with a conflicting ``convected``.
    """
    if convected is None:
        return bool(isentropic), bool(isentropic)
    if convected not in CONVECTED_CHOICES:
        raise ValueError(f"convected must be one of {CONVECTED_CHOICES}; got {convected!r}")
    if isentropic and convected != "none":
        raise ValueError(
            f"isentropic=True already removes every convected wave; it conflicts with convected={convected!r}"
        )
    return convected in ("composition", "none"), convected in ("entropy", "none")


@dataclass
class AcousticBlocks:
    """Frequency-independent blocks + frozen context, built once for a sweep."""

    J_alg: sp.csc_matrix  # complex, the converged Jacobian (zero-frequency operator)
    M: sp.csc_matrix  # complex, storage (zero unless volumes are present)
    duct_stamps: List[DuctStamp]  # per-duct P(omega) data
    prob: object  # the CompiledProblem (read-only, for source/boundary dispatch)
    x_bar: np.ndarray  # frozen mean state
    n: int
    u_floor: float = 1e-8
    # dynamic-source S(omega) data: per-element stamps + the active-flame downstream
    # edges kept physical under isentropic assembly.  Empty -> no source.
    source_stamps: list = field(default_factory=list)
    flame_edges: frozenset = field(default_factory=frozenset)
    # transfer-matrix TRANSFER_MATRIX element stamps: each overwrites its acoustic rows
    # with a user w_down = TM(omega) w_up relation (stamps.build_tm_stamps).  Empty -> none.
    tm_stamps: list = field(default_factory=list)
    # force isentropic perturbations (rho' = p'/c^2): the entropy wave is pinned to zero
    # on every edge (stamps.stamp_isentropic).  Reduces the 3-wave system to the two
    # acoustic waves -- standard acoustic analysis -- with no change in operator size.
    isentropic: bool = False
    # freeze the composition scalars' convection (their transport keeps the steady, delay-free
    # relation): the other half of the classic "isentropic" reduction, controlled independently
    # so entropy and composition waves can be kept or removed one at a time (resolve_convected).
    freeze_composition: bool = False
    # cached fixed-pattern assemblers keyed by with_boundaries (lazy; see _build_plan)
    _plans: dict = field(default_factory=dict, repr=False, compare=False)

    def __repr__(self) -> str:
        """Concise operator summary: dimension, duct count, wave model, and any dynamic sources."""
        if self.isentropic and self.freeze_composition:
            kind = "isentropic (2-wave)"
        elif self.isentropic:
            kind = "entropy pinned, composition convecting"
        elif self.freeze_composition:
            kind = "entropy convecting, composition frozen"
        else:
            kind = "full (3-wave)"
        src = f", {len(self.source_stamps)} dynamic source(s)" if self.source_stamps else ""
        return f"AcousticBlocks: operator dim {self.n}, {len(self.duct_stamps)} duct(s), {kind}{src}"

    @property
    def has_sources(self) -> bool:
        """Whether any dynamic-source ``S(omega)`` feedback is present."""
        return bool(self.source_stamps)


def build_acoustic_blocks(prob, x_bar, eps=None, eps_fb=1e-6, u_floor=1e-8, isentropic=False, convected=None):
    """Build the frozen blocks at the mean state ``x_bar``.

    ``J_alg`` is assembled with the regularizations turned down (``kappa = 0``).  ``M``
    is the storage block (all-zero when no storage element is present).  The duct phase
    data is precomputed here and restamped cheaply per frequency.

    Parameters
    ----------
    prob : CompiledProblem
        The compiled network.
    x_bar : ndarray
        Converged mean-flow state, shape ``(n_solve, E)``.
    eps, eps_fb : float, optional
        Complex-step and feedback step sizes for the Jacobian assembly.
    u_floor : float, optional
        Speed below which a station is treated as quiescent.
    isentropic : bool, optional
        Pin the entropy characteristic to zero on every edge (``rho' = p'/c^2``) **and**
        freeze the composition scalars' convection, reducing the operator to the two
        acoustic waves without changing its size (see :func:`stamps.stamp_isentropic`).
        Default False.  The shorthand for ``convected="none"``.
    convected : str, optional
        Fine-grained control over which convected wave families remain live: ``"all"``
        (default, the full operator), ``"entropy"`` (entropy convects, composition
        frozen), ``"composition"`` (composition convects, entropy pinned), ``"none"``
        (identical to ``isentropic=True``).  Lets entropy and composition waves be
        removed one at a time to attribute a mode's damping or drive to its carrier.

    Returns
    -------
    AcousticBlocks
        The frozen operator blocks.
    """
    pin_entropy, freeze_composition = resolve_convected(isentropic, convected)
    isentropic = pin_entropy
    if eps is None:
        eps = 1e-4 * prob.var_scale[0]
    x_bar = np.ascontiguousarray(x_bar)
    J = jacobian(prob, x_bar, eps, eps_fb, 0.0).astype(np.complex128)
    n = J.shape[0]
    # every stamp reads its caloric coupling straight from the edge-state table (filled per
    # edge by that edge's own thermo model), so the char-map stamps stay consistent with J_alg.
    M = build_storage(prob, x_bar)
    duct_stamps = build_duct_stamps(prob, x_bar, u_floor)
    source_stamps, flame_edges = build_source_stamps(prob, x_bar, u_floor)
    if isentropic:
        # a passive heat-adding element must also keep its downstream energy row physical
        # under the entropy pin, or its jump degrades to mass-flux continuity
        est = states_table(prob, x_bar, caloric=True)
        flame_edges = frozenset(set(flame_edges) | heat_addition_edges(prob, est))
    tm_stamps = build_tm_stamps(prob, x_bar, u_floor)
    return AcousticBlocks(
        J_alg=J.tocsc(),
        M=M,
        duct_stamps=duct_stamps,
        prob=prob,
        x_bar=x_bar,
        n=n,
        u_floor=u_floor,
        isentropic=bool(isentropic),
        freeze_composition=bool(freeze_composition),
        source_stamps=source_stamps,
        flame_edges=flame_edges,
        tm_stamps=tm_stamps,
    )


def _assemble_reference(omega, blocks: AcousticBlocks, with_boundaries=True, with_sources=True, with_storage=True):
    """Reference assembly of ``A(omega)`` via LIL stamping (the trusted, slow path).

    The cached ``J_alg`` is never mutated: a fresh LIL copy receives the i*omega*M
    scaling and the omega-dependent stamps.  At ``omega = 0`` with no ducts and only
    inherited boundaries this returns exactly ``J_alg`` (the founding consistency);
    with ducts the phase rows reduce to wave-amplitude continuity -- physically
    equivalent to the steady duct rows.

    ``with_storage`` (default True) adds the storage block ``i*omega*M``;
    :func:`_build_plan` sets it ``False`` to capture a storage-free ``base`` (the
    storage's additive contribution is folded in per frequency by the fast fill, like
    the dynamic source).

    ``with_boundaries`` controls the terminal reflection closure ``R(omega)``
    (``stamps.stamp_boundaries``).  The measurement driver (``response.py``) sets it
    ``False`` because it closes every terminal itself with independent prescribed
    incoming waves; the physical forced/stability drivers leave it ``True`` so each
    terminal carries its declared ``PerturbationBC``.

    ``with_sources`` (default True) stamps the dynamic source ``S(omega)``;
    :func:`_build_plan` sets it ``False`` to capture a source-free ``base`` (the source's
    additive contribution is folded in per frequency by the fast fill, avoiding the
    catastrophic cancellation of baking a large ``S`` into ``base`` and subtracting it).

    This builds the matrix from scratch every call; :func:`assemble_acoustic` is the
    fast path that reuses it once to capture the (omega-independent) sparsity pattern.
    """
    storage = with_storage and blocks.M.nnz
    A = (blocks.J_alg + 1j * omega * blocks.M).tolil() if storage else blocks.J_alg.tolil()
    stamp_propagation(
        A,
        omega,
        blocks.duct_stamps,
        blocks.u_floor,
        skip_entropy=blocks.isentropic,
        skip_composition=blocks.freeze_composition,
    )
    # transfer-matrix elements overwrite their own acoustic rows (like the duct phase); a
    # different row set than the source, so it commutes with the source stamp below.
    stamp_transfer_matrix(A, omega, blocks.tm_stamps, blocks.u_floor, skip_entropy=blocks.isentropic)
    # dynamic-source feedback S(omega): *adds* onto the J_alg rows (node rows for a mass
    # source, the downstream energy row for a flame), so it runs before the isentropic pin,
    # which then leaves the active-flame energy rows physical (blocks.flame_edges).
    if with_sources:
        stamp_sources(A, omega, blocks.source_stamps)
    if with_boundaries:
        stamp_boundaries(A, omega, blocks.prob, blocks.x_bar)
    if blocks.isentropic:
        # pin the entropy wave to zero on every edge (rho' = p'/c^2); overrides the
        # entropy rows the duct/boundary stamps wrote.  omega-independent.  Active-flame
        # downstream edges are skipped so their heat-release energy row stays physical.
        est = states_table(blocks.prob, blocks.x_bar, caloric=True)
        stamp_isentropic(A, blocks.prob, est, skip_edges=blocks.flame_edges)
    return A.tocsc()


class _AssemblyPlan:
    """Fixed sparsity pattern of ``A(omega)`` plus a fast per-omega value fill.

    The *structure* of ``A(omega)`` does not depend on ``omega`` -- only the duct
    phases ``e^{-i*omega*tau}`` and any frequency-dependent terminal closure change
    *values*, never which entries exist.  So the pattern (CSC ``indptr``/``indices``)
    and the omega-independent entries (``base``) are captured once; each subsequent
    ``A(omega)`` is built by scattering the few omega-dependent values into a copy of
    ``base``, with no LIL construction and no re-sort.

    This is the assembly hot path under the contour sweep: it replaces the
    ``O(edges)`` Python-level sparse-row overwrites and the ``tolil``/``tocsc`` round
    trip of :func:`_assemble_reference` with one array copy and a handful of
    vectorized operations per node.  The duct fill is a single complex ``exp`` and a
    fancy-index assignment; the (few) boundary terminals reuse the exact closure of
    :func:`stamps._terminal_closure`.

    Attributes
    ----------
    indptr, indices : ndarray
        Canonical CSC structure shared by every ``A(omega)``.
    shape : tuple
        Operator shape.
    base : ndarray
        Complex ``data`` array holding the omega-independent entries (the non-stamped
        ``J_alg`` rows and the constant parts of the duct rows); the omega-dependent
        slots are zeroed and overwritten per call.
    phase_slots, phase_tau, phase_coeff : ndarray
        For each omega-dependent duct entry: its index in ``data``, its transit time
        ``tau``, and its constant coefficient.  The entry's value is
        ``phase_coeff * exp(-i*omega*tau)``.
    bnd : list
        ``(terminal, bc, {row: slot_indices})`` for the explicitly-closed terminals.
    """

    __slots__ = (
        "indptr",
        "indices",
        "shape",
        "base",
        "phase_slots",
        "phase_tau",
        "phase_coeff",
        "prob",
        "est",
        "x_bar",
        "bnd",
        "src_slots",
        "m_slots",
        "m_coeff",
        "tm_slots",
    )

    def __init__(
        self,
        indptr,
        indices,
        shape,
        base,
        phase_slots,
        phase_tau,
        phase_coeff,
        prob,
        est,
        x_bar,
        bnd,
        src_slots,
        m_slots,
        m_coeff,
        tm_slots,
    ):
        self.indptr = indptr
        self.indices = indices
        self.shape = shape
        self.base = base
        self.phase_slots = phase_slots
        self.phase_tau = phase_tau
        self.phase_coeff = phase_coeff
        self.prob = prob
        self.est = est
        self.x_bar = x_bar  # frozen mean state; driven-composition seats read its mean fractions
        self.bnd = bnd
        # storage block: each entry accumulates i*omega*m_coeff onto its slot (base holds
        # only J_alg there), so a storage row is J_alg + i*omega*M.
        self.m_slots = m_slots
        self.m_coeff = m_coeff
        # dynamic-source S(omega): (slot, constant coeff, transfer fn); each accumulates
        # coeff*F(omega/2pi) onto its slot, so a sourced row is J_alg + S(omega).
        self.src_slots = src_slots
        # transfer-matrix entries: (slotmatrix (n_written x 3), L_up, transfer, N, n_written);
        # each overwrites data[slot[i,k]] = -(TM(omega) L_up)[i,k], the L_down part in `base`.
        self.tm_slots = tm_slots

    def assemble(self, omega):
        """Build ``A(omega)`` as a CSC matrix by the fast fill."""
        data = self.base.copy()
        if self.m_slots.size:
            # storage block: each entry adds i*omega*coeff onto J_alg (accumulate, not overwrite)
            data[self.m_slots] += 1j * omega * self.m_coeff
        if self.phase_slots.size:
            # the only bulk omega-dependence: each duct phase entry = coeff * e^{-i w tau}
            data[self.phase_slots] = self.phase_coeff * np.exp(-1j * omega * self.phase_tau)
        for t, bc, rowslots in self.bnd:
            for row, _cols, coeff, _rhs in _terminal_closure(self.prob, self.est, t, bc, omega, self.x_bar):
                slots = rowslots.get(row)
                if slots is not None:  # entropy rows are dropped under isentropic mode
                    data[slots] = coeff
        if self.src_slots:
            freq = omega / (2.0 * np.pi)  # transfer functions are in Hz (project convention)
            for s, coeff, transfer in self.src_slots:
                data[s] += coeff * complex(np.asarray(transfer(freq)).reshape(-1)[0])
        if self.tm_slots:
            freq = omega / (2.0 * np.pi)  # transfer matrices are in Hz (project convention)
            for slotm, L_up, transfer, N, n_written in self.tm_slots:
                block = _tm_block(transfer, L_up, N, freq)  # -(TM(omega) L_up)[:N]  (N x 3)
                for i in range(n_written):
                    data[slotm[i]] = block[i, :]
        A = sp.csc_matrix((data, self.indices, self.indptr), shape=self.shape)
        A.has_sorted_indices = True  # indices/indptr come canonical and are reused unchanged
        return A


def _build_plan(blocks: AcousticBlocks, with_boundaries):
    """Capture the fixed sparsity pattern and per-omega fill data for :class:`_AssemblyPlan`."""
    prob = blocks.prob
    tr0 = int(prob.transport_row0)

    # The omega-dependent duct entries, as (row, col, constant coeff, tau).  Structural
    # zeros (exactly-zero L entries) never enter the pattern, so they are skipped.  The
    # entropy (h) phase is omega-dependent only on a *flowing* duct; on a quiescent one it
    # is the stationary P0 = 1 (a constant already folded into base).  Under isentropic
    # mode the entropy rows are pinned to the constant h = 0 (in base), so the entropy phase
    # is dropped entirely.
    duct_entries = []
    for st in blocks.duct_stamps:
        flowing = abs(st.u) > blocks.u_floor
        for j in range(3):
            if st.L0[0, j] != 0.0:
                duct_entries.append((st.row_f, st.cols0[j], -st.L0[0, j], st.tau_p))
            if st.L1[1, j] != 0.0:
                duct_entries.append((st.row_g, st.cols1[j], -st.L1[1, j], st.tau_m))
            if flowing and not blocks.isentropic and st.L0[2, j] != 0.0:
                duct_entries.append((st.row_h, st.cols0[j], -st.L0[2, j], st.tau_0))
        # composition phase: xi(head) - P0 xi(tail) = 0.  The tail entry -P0 = -e^{-i w tau_0}
        # is omega-dependent (coeff -1); the head +1 is constant (folded into base).  Dropped
        # when the composition convection is frozen, and on a quiescent duct.
        if flowing and not blocks.freeze_composition:
            for row, c0 in zip(st.comp_rows, st.comp_cols0):
                duct_entries.append((row, c0, -1.0, st.tau_0))

    # Boundary terminals.  A frequency-dependent closure entry can vanish at the
    # pattern-probe frequency yet be non-zero elsewhere, so every boundary slot is forced
    # into the pattern (added with value 0) rather than read off the probe assembly.
    bnd_meta, forced_rc = [], []
    est = None
    if with_boundaries and prob.node_bc:
        est = states_table(prob, blocks.x_bar, caloric=True)
        E = int(prob.n_edges)
        for t in find_terminals(prob):
            bc = prob.node_bc[t.node] if t.node < len(prob.node_bc) else None
            if bc is None or not getattr(bc, "stamps_terminal", False):
                continue
            entries = [
                (row, cols) for row, cols, _c, _r in _terminal_closure(prob, est, t, bc, _PLAN_OMEGA, blocks.x_bar)
            ]
            if blocks.isentropic:
                # entropy (transport) rows [tr0, tr0+E) are pinned to h = 0 in base; the boundary
                # fill must not overwrite them.  Acoustic node rows (< tr0) and scalar transport
                # rows (>= tr0+E, not pinned) are kept.
                entries = [(row, cols) for row, cols in entries if row < tr0 or row >= tr0 + E]
            bnd_meta.append((t, bc, entries))
            forced_rc.extend((row, c) for row, cols in entries for c in cols)

    # Dynamic source S(omega): each term adds factor[r]*coeff[c]*F(omega) onto row r,
    # column c.  Collected as (row, col, constant complex coeff, transfer) and forced into
    # the pattern (a transfer can vanish at the probe frequency yet be non-zero elsewhere).
    src_entries = []
    for st in blocks.source_stamps:
        for r, fr in zip(st.rows, st.factors):
            for term in st.terms:
                for c, v in zip(term.cols, term.coeff):
                    src_entries.append((int(r), int(c), complex(fr) * complex(v), term.transfer))
    forced_rc.extend((r, c) for (r, c, _co, _tf) in src_entries)

    # Storage block i*omega*M: each entry adds i*omega*coeff onto its (row, col) -- like the
    # source, it is assembled OUT of `base` (with_storage=False below) and accumulated per
    # frequency, so `base` holds only J_alg there (no large-M cancellation).  Forced into the
    # pattern (a coeff can coincide with an existing J_alg entry or open a new slot).
    m_entries = []
    if blocks.M.nnz:
        Mco = blocks.M.tocoo()
        m_entries = [(int(r), int(c), complex(v)) for r, c, v in zip(Mco.row, Mco.col, Mco.data)]
        forced_rc.extend((r, c) for (r, c, _v) in m_entries)

    # Transfer-matrix elements: the upstream block -(TM(omega) L_up) is omega-dependent, so
    # force its (row, up-col) slots into the pattern (its constant downstream L_down entries
    # are captured in `base` by the reference assembly).  n_written = 2 under isentropic (the
    # entropy row is pinned by stamp_isentropic), else the matrix dimension.
    tm_records = []
    for st in blocks.tm_stamps:
        n_written = 2 if blocks.isentropic else st.N
        for i in range(n_written):
            forced_rc.extend((int(st.rows[i]), int(c)) for c in st.up_cols)
        tm_records.append((st, n_written))

    # Canonical pattern: the reference assembly (correct base values) unioned with the
    # forced boundary/source slots; sum_duplicates merges the forced zeros into existing
    # entries.  The source is assembled OUT of `base` (with_sources=False) -- its slots are
    # forced into the pattern above and filled per frequency by the fast accumulate, so the
    # base holds only J_alg there (no large-S cancellation).
    ref = _assemble_reference(_PLAN_OMEGA, blocks, with_boundaries, with_sources=False, with_storage=False).tocoo()
    if forced_rc:
        rows_all = np.concatenate([ref.row, np.array([r for r, _ in forced_rc], dtype=ref.row.dtype)])
        cols_all = np.concatenate([ref.col, np.array([c for _, c in forced_rc], dtype=ref.col.dtype)])
        vals_all = np.concatenate([ref.data.astype(np.complex128), np.zeros(len(forced_rc), np.complex128)])
    else:
        rows_all, cols_all, vals_all = ref.row, ref.col, ref.data.astype(np.complex128)
    T = sp.csc_matrix((vals_all, (rows_all, cols_all)), shape=ref.shape)
    T.sum_duplicates()
    T.sort_indices()
    indptr, indices = T.indptr.copy(), T.indices.copy()
    base = T.data.astype(np.complex128).copy()

    def slot(row, col):
        # CSC: column-major, so a column's stored rows are indices[indptr[col]:indptr[col+1]].
        lo, hi = int(indptr[col]), int(indptr[col + 1])
        pos = lo + int(np.searchsorted(indices[lo:hi], row))
        if pos >= hi or indices[pos] != row:
            raise RuntimeError(f"assembly-plan slot ({row}, {col}) missing from the captured pattern")
        return pos

    phase_slots = np.empty(len(duct_entries), dtype=np.intp)
    phase_tau = np.empty(len(duct_entries), dtype=np.float64)
    phase_coeff = np.empty(len(duct_entries), dtype=np.complex128)
    for i, (row, col, coeff, tau) in enumerate(duct_entries):
        phase_slots[i], phase_tau[i], phase_coeff[i] = slot(row, col), tau, coeff
    base[phase_slots] = 0.0  # zero the omega-dependent duct slots (overwritten per call)

    bnd = []
    for t, bc, rowcols in bnd_meta:
        rowslots = {}
        for row, cols in rowcols:
            s = np.array([slot(row, c) for c in cols], dtype=np.intp)
            rowslots[row] = s
            base[s] = 0.0  # zero the boundary slots (overwritten per call)
        bnd.append((t, bc, rowslots))

    # Source slots: `base` holds only J_alg there (the source was assembled out), so the
    # per-omega fill simply accumulates coeff*F(omega) onto it (A[r,c] = J_alg + S(omega)).
    src_slots = [(slot(r, c), coeff, transfer) for (r, c, coeff, transfer) in src_entries]

    # Storage slots: `base` holds only J_alg there (storage assembled out), so the per-omega
    # fill accumulates i*omega*coeff onto it (A[r,c] = J_alg + i*omega*M).  NOT zeroed.
    m_slots = np.array([slot(r, c) for (r, c, _v) in m_entries], dtype=np.intp)
    m_coeff = np.array([v for (_r, _c, v) in m_entries], dtype=np.complex128)

    # Transfer-matrix slots: `base` holds the (constant) downstream L_down entries; the
    # upstream slots are zeroed here and overwritten per frequency with -(TM(omega) L_up).
    tm_slots = []
    for st, n_written in tm_records:
        slotm = np.empty((n_written, 3), dtype=np.intp)
        for i in range(n_written):
            for k, c in enumerate(st.up_cols):
                s = slot(int(st.rows[i]), int(c))
                slotm[i, k] = s
                base[s] = 0.0
        tm_slots.append((slotm, st.L_up.astype(np.complex128), st.transfer, st.N, n_written))

    return _AssemblyPlan(
        indptr,
        indices,
        ref.shape,
        base,
        phase_slots,
        phase_tau,
        phase_coeff,
        prob,
        est,
        blocks.x_bar,
        bnd,
        src_slots,
        m_slots,
        m_coeff,
        tm_slots,
    )


def assemble_acoustic(omega, blocks: AcousticBlocks, with_boundaries=True):
    """Stamp the full ``A(omega) = J_alg + i*omega*M + P(omega) + S(omega) + R(omega)``.

    Fast path over :func:`_assemble_reference`: the sparsity pattern of ``A(omega)`` is
    independent of ``omega`` (the stamps overwrite fixed rows/columns; only the duct
    phases and any frequency-dependent terminal closure change values), so it is captured
    once into a cached :class:`_AssemblyPlan` and each subsequent ``A(omega)`` is built by
    scattering the few omega-dependent values into a copy of the omega-independent entries
    -- no LIL build, no re-sort.  This is what makes the contour sweep (hundreds of
    factorizations) scale to large networks.  Results are identical to
    :func:`_assemble_reference` to round-off.

    ``with_boundaries`` controls the terminal reflection closure ``R(omega)``; the plan is
    cached per value on ``blocks``.  A dynamic source ``S(omega)`` and the storage block
    ``i*omega*M`` both ride the fast path too -- their (frequency-dependent) contributions
    are accumulated onto fixed slots per frequency, so the operator is assembled in full
    (``A = J_alg + i*omega*M + P + S + R``) without ever falling back to the slow path.

    Parameters
    ----------
    omega : complex
        Angular frequency (rad/s), real for a forced sweep or complex on a stability
        contour.
    blocks : AcousticBlocks
        The frozen operator blocks (carries the lazily-built plan cache).
    with_boundaries : bool, optional
        Whether to stamp the terminal closures ``R(omega)`` (default True).

    Returns
    -------
    scipy.sparse.csc_matrix
        ``A(omega)``.
    """
    plan = blocks._plans.get(with_boundaries)
    if plan is None:
        plan = _build_plan(blocks, with_boundaries)
        blocks._plans[with_boundaries] = plan
    return plan.assemble(omega)
