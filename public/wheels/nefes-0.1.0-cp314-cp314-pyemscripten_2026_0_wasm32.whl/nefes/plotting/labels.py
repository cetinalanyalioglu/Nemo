"""Central LaTeX-label toggle for Nefes figures.

Plotly renders MathJax (``$...$``) only where a MathJax runtime is present.  In a
plain notebook kernel, a static HTML/PNG export, or some IDE viewers the math does
not typeset and the user is left staring at the raw source -- ``$f_{0}$``,
``\\rho``, stray braces.  This module is the single switch that decides, globally,
whether Nefes labels are emitted as MathJax or as a Unicode plain-text fallback.

Usage::

    from nefes.plotting import use_latex
    use_latex(False)        # all subsequent Nefes figures use plain Unicode labels
    use_latex(True)         # back to MathJax (the default)

Every Nefes plotting routine, and every figure built in the example notebooks, routes
its labels through :func:`mathify` (for a bare LaTeX *fragment*) or :func:`tex` (for
a complete, possibly ``$``-delimited label), so flipping the toggle restyles them all.
When LaTeX is on both are essentially no-ops; when off they run :func:`detex`, a
best-effort LaTeX-to-Unicode converter that guarantees no ``$``, backslash or stray
brace survives into the figure.
"""

import re

# Default state: MathJax on; flip with use_latex(False) for environments where MathJax does not render.
_USE_LATEX = True

# LaTeX special characters to escape when arbitrary text is dropped into a ``\text{}``
# group, so a label cannot break the surrounding MathJax string.
_TEX_ESCAPE = {
    "\\": r"\textbackslash{}",
    "&": r"\&",
    "%": r"\%",
    "$": r"\$",
    "#": r"\#",
    "_": r"\_",
    "{": r"\{",
    "}": r"\}",
    "~": r"\textasciitilde{}",
    "^": r"\textasciicircum{}",
}

# Named control sequences (Greek and a handful of operators/relations) mapped to a
# single Unicode glyph.  Anything unlisted keeps its name verbatim (the backslash is
# dropped), so an unknown ``\foo`` degrades to ``foo`` rather than leaking a slash.
_NAMED = {
    "alpha": "α",
    "beta": "β",
    "gamma": "γ",
    "delta": "δ",
    "epsilon": "ε",
    "varepsilon": "ε",
    "zeta": "ζ",
    "eta": "η",
    "theta": "θ",
    "vartheta": "ϑ",
    "iota": "ι",
    "kappa": "κ",
    "lambda": "λ",
    "mu": "μ",
    "nu": "ν",
    "xi": "ξ",
    "omicron": "ο",
    "pi": "π",
    "rho": "ρ",
    "varrho": "ϱ",
    "sigma": "σ",
    "varsigma": "ς",
    "tau": "τ",
    "upsilon": "υ",
    "phi": "φ",
    "varphi": "φ",
    "chi": "χ",
    "psi": "ψ",
    "omega": "ω",
    "Gamma": "Γ",
    "Delta": "Δ",
    "Theta": "Θ",
    "Lambda": "Λ",
    "Xi": "Ξ",
    "Pi": "Π",
    "Sigma": "Σ",
    "Upsilon": "Υ",
    "Phi": "Φ",
    "Psi": "Ψ",
    "Omega": "Ω",
    "angle": "∠",
    "to": "→",
    "rightarrow": "→",
    "leftarrow": "←",
    "cdot": "·",
    "times": "×",
    "partial": "∂",
    "infty": "∞",
    "pm": "±",
    "mp": "∓",
    "approx": "≈",
    "propto": "∝",
    "langle": "⟨",
    "rangle": "⟩",
    "nabla": "∇",
    "leq": "≤",
    "geq": "≥",
    "neq": "≠",
    "ell": "ℓ",
    "Re": "Re",
    "Im": "Im",
}

# Subscript / superscript Unicode coverage.  A group converts only when *every*
# character maps; otherwise it keeps its ``_``/``^`` marker, so a name-bearing
# subscript like ``_{OP}`` reads as ``_OP`` rather than running into the stem.
_SUB = {c: u for c, u in zip("0123456789+-=()aeoxhklmnpstijruv", "₀₁₂₃₄₅₆₇₈₉₊₋₌₍₎ₐₑₒₓₕₖₗₘₙₚₛₜᵢⱼᵣᵤᵥ")}
_SUP = {c: u for c, u in zip("0123456789+-=()ni", "⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻⁼⁽⁾ⁿⁱ")}

# A ``_``/``^`` script: either a brace group or the single character that follows.
_SCRIPT = re.compile(r"([_^])(?:\{([^{}]*)\}|([^\s{}_^]))")

# Accent commands mapped to the combining mark that follows their group's contents.
_ACCENTS = {
    "dot": "̇",
    "ddot": "̈",
    "hat": "̂",
    "widehat": "̂",
    "tilde": "̃",
    "widetilde": "̃",
    "bar": "̅",
    "overline": "̅",
    "vec": "⃗",
}

# Font/wrapper commands whose brace group is kept verbatim, and spacing commands mapped to plain spaces.
_WRAPPERS = ("text", "mathrm", "mathbf", "mathit", "mathsf", "operatorname", "boldsymbol")
_SCRIPTED_WRAP = re.compile(r"([_^])\\(?:" + "|".join(_WRAPPERS) + r")\s*\{")
_SPACING = (
    ("\\;", " "),
    ("\\,", " "),
    ("\\:", " "),
    ("\\>", " "),
    ("\\quad", "  "),
    ("\\qquad", "   "),
    ("\\ ", " "),
    ("\\!", ""),
)


def use_latex(enabled=True):
    """Enable or disable MathJax (``$...$``) labels on Nefes figures process-wide.

    Parameters
    ----------
    enabled : bool, optional
        ``True`` (default) keeps the MathJax labels; ``False`` switches every Nefes
        figure to the Unicode plain-text fallback produced by :func:`detex`.

    Returns
    -------
    bool
        The new state, so a caller can log or assert on it.
    """
    global _USE_LATEX
    _USE_LATEX = bool(enabled)
    return _USE_LATEX


def latex_enabled():
    """Whether Nefes figures currently emit MathJax labels (see :func:`use_latex`)."""
    return _USE_LATEX


def mathify(fragment):
    """Render a bare LaTeX *fragment* as a figure label honoring the global toggle.

    ``fragment`` is a LaTeX body without the surrounding ``$`` (e.g. ``f_{0}`` or
    ``p'/\\rho c``).  Returns ``$fragment$`` when LaTeX is enabled, else the Unicode
    fallback from :func:`detex`.
    """
    return f"${fragment}$" if _USE_LATEX else detex(fragment)


def tex(label):
    """Pass through a complete label (possibly ``$``-delimited), honoring the toggle.

    Use for fixed axis titles such as ``r"$f\\;(\\mathrm{Hz})$"``: returns the label
    unchanged when LaTeX is enabled, else its :func:`detex` Unicode form.
    """
    if label is None:
        return None
    return label if _USE_LATEX else detex(label)


def tex_text(s):
    """Escape arbitrary text for safe insertion inside a LaTeX ``\\text{}`` group.

    Replaces the LaTeX-special characters (``\\ & % $ # _ { } ~ ^``) with their escaped
    forms, so an arbitrary element label cannot break the MathJax string it is subscripted
    into.

    Parameters
    ----------
    s : object
        The label; coerced with ``str``.

    Returns
    -------
    str
        The escaped text.
    """
    return "".join(_TEX_ESCAPE.get(ch, ch) for ch in str(s))


# -- LaTeX -> Unicode fallback ---------------------------------------------------


def _script(inner, table, marker):
    """Unicode sub/superscript for ``inner`` if fully mappable, else ``inner`` behind ``marker``."""
    if inner and all(ch in table for ch in inner):
        return "".join(table[ch] for ch in inner)
    return marker + inner


def _render_script(m):
    """Render one ``_``/``^`` script, whether it is braced or a single character."""
    marker = m.group(1)
    inner = m.group(2) if m.group(2) is not None else m.group(3)
    return _script(inner, _SUP if marker == "^" else _SUB, marker)


def _group(s, start):
    """Contents and end index of the brace group opening at ``s[start]``, or ``(None, None)``."""
    depth = 0
    for j in range(start, len(s)):
        if s[j] == "{":
            depth += 1
        elif s[j] == "}":
            depth -= 1
            if depth == 0:
                return s[start + 1 : j], j + 1
    return None, None


def _replace_commands(s, names, render):
    """Rewrite every ``\\name{...}`` in ``s`` with ``render(name, contents)``.

    Brace matching is balanced, so a command whose group holds further braces (say
    ``\\mathrm{s^{-1}}``) is recognized as a whole rather than left behind.
    """
    pattern = re.compile(r"\\(" + "|".join(names) + r")\s*\{")
    out, i = [], 0
    while True:
        m = pattern.search(s, i)
        if m is None:
            out.append(s[i:])
            return "".join(out)
        contents, end = _group(s, m.end() - 1)
        if contents is None:  # unbalanced; leave the rest untouched
            out.append(s[i:])
            return "".join(out)
        out.append(s[i : m.start()])
        out.append(render(m.group(1), contents))
        i = end


def _repeat(fn, s):
    """Apply ``fn`` until it stops changing ``s``, so nested constructs unwind."""
    prev = None
    while prev != s:
        prev = s
        s = fn(s)
    return s


def detex(s):
    """Best-effort conversion of a LaTeX string to a Unicode plain-text label.

    Handles the constructs Nefes actually emits -- Greek letters, ``\\dot``/``\\widehat``
    and the other accents, ``\\text``/``\\mathrm`` wrappers, spacing commands,
    ``\\to``/``\\angle`` and friends, and ``_``/``^`` scripts -- and strips anything left
    so the result never contains ``$``, a backslash, or a stray brace.  Not a general
    LaTeX engine; it is a readability fallback, not a typesetter.

    Examples
    --------
    >>> detex(r"$|\\widehat{p}|$")
    '|p̂|'
    >>> detex(r"\\text{growth rate } \\sigma\\;[\\mathrm{s^{-1}}]")
    'growth rate σ [s⁻¹]'
    """
    s = str(s).replace("$", "")
    # accents own their brace group and leave a combining mark on its contents
    s = _repeat(lambda t: _replace_commands(t, _ACCENTS, lambda n, c: c + _ACCENTS[n]), s)
    # a wrapper right behind a script marker keeps the group, so the script stays whole
    s = _repeat(lambda t: _SCRIPTED_WRAP.sub(r"\1{", t), s)
    # remaining text/font wrappers -> their contents
    s = _repeat(lambda t: _replace_commands(t, _WRAPPERS, lambda n, c: c), s)
    for tok, rep in _SPACING:
        s = s.replace(tok, rep)
    s = re.sub(r"\\([A-Za-z]+)", lambda m: _NAMED.get(m.group(1), m.group(1)), s)
    # one pass over the scripts, braced or single character, so a marker kept for an
    # unmappable group is not mistaken for the start of another script
    s = _SCRIPT.sub(_render_script, s)
    s = s.replace("{", "").replace("}", "").replace("\\", "")
    return re.sub(r"\s+", " ", s).strip()
