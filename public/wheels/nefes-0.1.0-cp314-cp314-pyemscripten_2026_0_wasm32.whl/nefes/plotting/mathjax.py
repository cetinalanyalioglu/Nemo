"""MathJax for the ``$...$`` labels of Plotly figures in a notebook (:func:`use_mathjax`).

Plotly typesets math in a figure label only when the page holding the figure carries
MathJax under the global name ``MathJax``.  JupyterLab and Jupyter Notebook 7 do render
math in their own Markdown cells, but keep their MathJax packed inside the application
bundle, where Plotly cannot reach it, so a figure label shows its source (``$S_{11}$``)
instead of the symbol.  :func:`use_mathjax` puts a copy in the page; call it next to the
theme, at the top of a notebook::

    from nefes.plotting import use_mathjax, use_nefes_theme

    use_nefes_theme()
    use_mathjax()

The copy is fetched once per page and typesets nothing on its own, so the front end keeps
rendering the Markdown cells its own way; it only answers Plotly's requests.  Fetching it
takes a moment, during which a figure still shows its label source: re-run such a cell.

This module exports :func:`use_mathjax` and the address it loads, :data:`MATHJAX_URL`.

See Also
--------
nefes.plotting.use_latex : plain-Unicode labels, for where MathJax cannot be reached.
"""

from __future__ import annotations

import json
from string import Template

#  MathJax 2.7.5 with the SVG configuration: the pairing Plotly builds its own notebook
#  output around, and the one its label typesetting is written against.
MATHJAX_URL = "https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS-MML_SVG"

#  Loads the library once per page (a front end that already exposes one is left alone)
#  and holds it back from typesetting the page itself: Plotly asks for each label.
_LOADER = Template("""<script>
(function () {
    if (window.MathJax) { return; }
    var config = document.createElement("script");
    config.type = "text/x-mathjax-config";
    config.text = 'MathJax.Hub.Config({skipStartupTypeset: true, messageStyle: "none",'
                + ' SVG: {font: "STIX-Web"}});';
    document.head.appendChild(config);
    var library = document.createElement("script");
    library.src = $url;
    document.head.appendChild(library);
})();
</script>""")


def use_mathjax(url: str = MATHJAX_URL) -> None:
    """Load MathJax into the notebook page, so ``$...$`` figure labels are typeset.

    Parameters
    ----------
    url : str, optional
        Address of the MathJax library, by default :data:`MATHJAX_URL` (version 2.7.5
        from a public host).  Point it at a local copy to work without a network; where
        no copy is reachable at all, use :func:`~nefes.plotting.use_latex` with ``False``
        instead and every Nefes label falls back to plain Unicode.

    Examples
    --------
    >>> from nefes.plotting import use_mathjax, use_nefes_theme
    >>> use_nefes_theme()                                        # doctest: +SKIP
    >>> use_mathjax()                                            # doctest: +SKIP

    See Also
    --------
    nefes.plotting.mathify : wrap a label fragment so the toggle can strip it.
    nefes.plotting.use_latex : switch the labels to plain Unicode instead.
    """
    from IPython.display import HTML, display

    display(HTML(_LOADER.substitute(url=json.dumps(url))))
