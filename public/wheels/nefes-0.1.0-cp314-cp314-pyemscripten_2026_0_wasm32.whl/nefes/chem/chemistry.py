"""Post-solve per-edge chemistry: the solved species composition of each edge.

The mean-flow solve transports the **feed-stream mixture fractions** ``xi`` (one per
distinct injected composition), not chemical species.  This module recovers the actual
species per edge from a converged state, for diagnostics / output:

* a **burnt** (``EQ_KERNEL``) edge sits at HP equilibrium, its product-species moles
  are captured by passing a sized warm-start cache to :func:`~nefes.derive.recover_all`
  (the equilibrium kernel writes its converged composition there);
* an **unburnt** (``EQ_FROZEN``) edge is the forward blend of the feed streams -- its
  species mass fractions are ``xi @ stream_Y`` over the network's distinct streams.

A perfect-gas edge carries no chemical species (its scalars, if any, are passive).

Beyond the compositions themselves, :func:`edge_formation_enthalpy` evaluates the
chemical part of an edge's absolute-enthalpy datum, and :func:`node_heat_release` turns
it into the heating power of a two-port element -- exact for the equilibrium flame,
where the temperature jump rides on the composition change alone.
"""

import numpy as np

from ..assembly.recover import ES_HT, ES_MDOT, NS_EST, recover_all
from ..elements.composite import is_composite
from ..elements.ids import STREAM_INTRODUCING
from ..solver.report import states_table
from ..thermo.api import EQ_KERNEL, EQ_MARKER, PERFECT_GAS
from ..thermo.edge_state import _feed_blocks, _product_blocks
from ..thermo.kernel import RU, _mix_cp_h
from .composition import build_streams

T_REF = 298.15  # formation-enthalpy reference temperature [K], the NASA-polynomial datum


def product_moles(prob, x):
    """Per-edge converged product-species moles ``[mol/kg]`` for ``EQ_KERNEL`` edges.

    Captures each burnt edge's converged composition in one recovery pass (no extra solve).
    Rows for perfect-gas / frozen edges stay zero, those kernels do not populate the cache.

    Parameters
    ----------
    prob : CompiledProblem
        The compiled network.
    x : ndarray
        Converged state, shape ``(n_solve, n_edges)``.

    Returns
    -------
    ndarray
        Shape ``(n_edges, Np)`` product-species moles per kg; ``Np == 0`` for a
        non-reacting model.
    """
    if prob.ti.shape[0] <= 6:  # not an equilibrium bundle (perfect gas / passive scalars)
        return np.zeros((prob.n_edges, 0))
    Np = int(prob.ti[6])
    cache = np.zeros((prob.n_edges, Np + 1))  # [moles_0..moles_{Np-1}, T]
    est = np.zeros((NS_EST, prob.n_edges))
    mr = int(getattr(prob, "marker_row", -1))
    recover_all(prob.edge_model, prob.tf, prob.ti, np.ascontiguousarray(x), prob.area, prob.n_elem, mr, est, cache)
    return cache[:, :Np]


def stream_mass_fractions(elements, species_set):
    """The ``(K, Ns)`` full-species_set mass fractions of the network's distinct feed streams.

    Re-runs the build-time stream discovery (deterministic auto-merge in node order), so
    stream ``k`` aligns with the transported mixture fraction ``xi[k]`` and the scalar
    label ``scalar_names[k]``.

    Parameters
    ----------
    elements : list of ElementSpec
        The network elements (in node order).
    species_set : nefes.thermo.SpeciesSet
        The species data.

    Returns
    -------
    ndarray
        Shape ``(K, Ns)`` -- each distinct stream's species mass fractions.
    """
    # Composites carry atomic sub-elements; flatten so ``residual_id`` is always defined.
    # Stream-introducing elements (inlets/sources/outlets) are top-level atomic and keep their
    # node order under the build's composite expansion, so the flattened stream sequence -- and
    # thus stream ``k`` <-> ``xi[k]`` -- stays aligned with the compiled problem.
    atomic = []
    for el in elements:
        atomic.extend(el.sub_elements if is_composite(el) else (el,))
    comps = [(el.composition_spec, el.basis) for el in atomic if el.residual_id in STREAM_INTRODUCING]
    stream_Y, _assignment = build_streams(species_set, comps)
    return stream_Y


def _fractions(names, moles, W, basis, threshold):
    """``{name: fraction}`` from per-kg moles, dropping entries below ``threshold``."""
    moles = np.asarray(moles, dtype=float)
    W = np.asarray(W, dtype=float)
    if basis == "mole":
        total = moles.sum()
        frac = moles / total if total > 0.0 else moles
    elif basis == "mass":
        frac = moles * W  # moles per kg times molar mass = mass fraction
    else:
        raise ValueError(f"basis must be 'mole' or 'mass'; got {basis!r}")
    return {name: float(f) for name, f in zip(names, frac) if abs(float(f)) > threshold}


def edge_species(prob, x, e, species_set, *, basis="mole", moles=None, stream_Y=None, threshold=1e-12):
    """Solved chemical species ``{name: fraction}`` on edge ``e``.

    Selects the reconstruction that matches the edge's thermo model: the converged
    equilibrium products for a burnt edge, or the unburnt forward blend of the feed
    streams (``xi @ stream_Y``) for a frozen / fresh one.  A perfect-gas edge (or a
    ``None`` species set) carries no chemical species and returns an empty dict.

    Parameters
    ----------
    prob : CompiledProblem
        The compiled network.
    x : ndarray
        Converged state, shape ``(n_solve, n_edges)``.
    e : int
        Edge id.
    species_set : nefes.thermo.SpeciesSet or None
        Species data; ``None`` (perfect gas) yields an empty result.
    basis : {"mole", "mass"}, optional
        Whether the fractions are mole or mass fractions (default ``"mole"``).
    moles, stream_Y : ndarray, optional
        Precomputed :func:`product_moles` / :func:`stream_mass_fractions` (pass them when
        querying many edges to avoid recomputing per call).
    threshold : float, optional
        Drop species whose fraction magnitude is below this (default ``1e-12``).

    Returns
    -------
    dict
        ``{species_name: fraction}`` in species set order, restricted to the present species.
    """
    model = int(prob.edge_model[e])
    if species_set is None or model == PERFECT_GAS:
        return {}
    # A marker-gated edge is bimodal at convergence: report the equilibrium products on a burnt
    # edge (marker >= 1/2) and the frozen feed-stream blend on a fresh one, matching the state's
    # blend gate.  The equilibrium product moles are captured for every reacting edge by
    # product_moles (the EQ_MARKER recovery runs the equilibrium leg regardless of the marker).
    burnt = model == EQ_KERNEL
    if model == EQ_MARKER:
        marker_row = int(getattr(prob, "marker_row", -1))
        # The marker is a sticky reachability label (a noisy-OR transport), so it stays bimodal
        # even where burnt gas is diluted by a fresh stream -- ~1 on any edge downstream of a
        # flame, ~0 upstream.  ``0.5`` is the crossover of ``marker_gate`` (equal frozen/equilibrium
        # weight), so reporting the equilibrium products above it and the frozen blend below it
        # matches the converged state.  The equilibrium solve runs on every marker-gated edge
        # regardless (product_moles), so a burnt edge is never denied its products.
        burnt = marker_row >= 0 and float(x[marker_row, e]) >= 0.5
    if burnt:
        nj = (product_moles(prob, x) if moles is None else moles)[e]
        idx = np.nonzero(np.asarray(species_set.product_mask))[0]
        names = [species_set.species[i].name for i in idx]
        W = np.asarray(species_set.molar_masses)[idx]
        return _fractions(names, nj, W, basis, threshold)
    # frozen / fresh marker-gated edge: the unburnt forward blend of the feed streams
    sY = stream_mass_fractions_for(prob, x, species_set) if stream_Y is None else stream_Y
    n_elem = prob.n_elem
    xi = np.asarray(x[3 : 3 + n_elem, e], dtype=float)
    Y = xi @ sY  # full-species_set mass fractions
    W = np.asarray(species_set.molar_masses)
    nj = Y / W  # mass fraction -> moles per kg
    names = [s.name for s in species_set.species]
    return _fractions(names, nj, W, basis, threshold)


def stream_mass_fractions_for(prob, x, species_set):  # pragma: no cover - convenience shim
    """Internal fallback used by :func:`edge_species` when ``stream_Y`` is not supplied.

    Requires the network elements, which a bare ``CompiledProblem`` does not carry, so the
    higher-level :class:`~nefes.shell.network.Solution` always passes ``stream_Y`` explicitly.

    Parameters
    ----------
    prob : CompiledProblem
        The compiled network (does not carry the element specs this needs).
    x : ndarray
        Converged state.
    species_set : nefes.thermo.SpeciesSet
        The species data.

    Raises
    ------
    ValueError
        Always -- the caller must supply ``stream_Y`` via ``Solution.species``.
    """
    raise ValueError("frozen-edge species need the network's stream compositions; query via Solution.species")


def edge_formation_enthalpy(prob, x, e, *, moles=None):
    """Mixture formation enthalpy [J/kg] of edge ``e`` at the 298.15 K reference.

    The enthalpy the edge's composition would carry at the reference temperature -- the
    chemical part of the absolute-enthalpy datum, so ``h_t - h_form`` is the sensible
    (thermal + kinetic) content of the flow.  A burnt edge evaluates its converged
    equilibrium products, a frozen / fresh edge the forward feed-stream blend, and a
    perfect-gas edge (no chemical species) returns ``0.0``.  Works from the compiled
    problem's packed thermo bundle alone -- no species set or network object needed.

    Parameters
    ----------
    prob : CompiledProblem
        The compiled network.
    x : ndarray
        Converged state, shape ``(n_solve, n_edges)``.
    e : int
        Edge id.
    moles : ndarray, optional
        Precomputed :func:`product_moles` (pass it when querying many edges).

    Returns
    -------
    float
        Formation enthalpy [J/kg] of the edge's mixture at 298.15 K.

    See Also
    --------
    node_heat_release : the heating power this underpins.
    """
    model = int(prob.edge_model[e])
    if model == PERFECT_GAS or prob.ti.shape[0] <= 6:
        return 0.0
    burnt = model == EQ_KERNEL
    if model == EQ_MARKER:
        # bimodal at convergence: equilibrium products past the marker-gate crossover,
        # the frozen feed blend below it (the same rule edge_species applies)
        marker_row = int(getattr(prob, "marker_row", -1))
        burnt = marker_row >= 0 and float(x[marker_row, e]) >= 0.5
    if burnt:
        nj = (product_moles(prob, x) if moles is None else moles)[e]
        coeffs, Tint, prod_A, ew = _product_blocks(prob.tf, prob.ti)
        # molar masses from the element matrix; the converged moles carry the equilibrium
        # solve's small mass-closure residual, so normalize to exactly one kg of mixture
        mass = float(nj @ (np.asarray(prod_A).T @ np.asarray(ew)))
    else:
        Nfeed, coeffs, Tint = _feed_blocks(prob.tf, prob.ti)
        xi = np.ascontiguousarray(x[3 : 3 + int(prob.n_elem), e], dtype=np.float64)
        nj = xi @ Nfeed  # feed-species moles per kg, the frozen forward blend
        # each packed stream is exactly one kg of mixture, so the blend's mass is sum(xi)
        mass = float(np.sum(xi))
    _cp, sum_nh = _mix_cp_h(np.ascontiguousarray(coeffs), np.ascontiguousarray(Tint), np.ascontiguousarray(nj), T_REF)
    return float(RU * T_REF * sum_nh / mass)


def node_heat_release(prob, x, n, *, est=None, moles=None):
    """Heat release rate [W] of the two-port element ``n`` from its converged edge states.

    The sensible total-enthalpy rise of the through-flow,
    ``Q = mdot [ (h_t - h_form)_out - (h_t - h_form)_in ]``, with each edge's formation
    enthalpy at the 298.15 K reference (:func:`edge_formation_enthalpy`).  For the
    perfect-gas heat-addition flame this recovers its ``Qdot`` parameter from the
    solution; for the reacting equilibrium flame -- which conserves the absolute total
    enthalpy -- it equals the formation-enthalpy drop from frozen reactants to
    equilibrium products, the exact heating power with no specific-heat approximation.
    Positive heats the flow; an adiabatic element returns ``~ 0``.

    Parameters
    ----------
    prob : CompiledProblem
        The compiled network.
    x : ndarray
        Converged state, shape ``(n_solve, n_edges)``.
    n : int
        Node (element) index; must be a two-port element with a single through-flow
        direction at the mean state.
    est : ndarray, optional
        Precomputed edge-state table (:func:`~nefes.solver.report.states_table`).
    moles : ndarray, optional
        Precomputed :func:`product_moles` (pass it when querying many elements).

    Returns
    -------
    float
        Heat release rate [W].
    """
    if est is None:
        est = states_table(prob, np.asarray(x), caloric=False)
    base = int(prob.row_ptr[n])
    deg = int(prob.row_ptr[n + 1]) - base
    if deg != 2:
        raise ValueError(f"heat release is defined for a two-port element; node {n} has {deg} ports")
    ports = [(int(prob.col_edge[base + i]), int(prob.orient[base + i])) for i in range(2)]
    outs = [(e, s) for (e, s) in ports if s * float(est[ES_MDOT, e]) > 0.0]
    ins = [(e, s) for (e, s) in ports if s * float(est[ES_MDOT, e]) <= 0.0]
    if len(outs) != 1 or len(ins) != 1:
        raise ValueError(f"node {n} needs a single through-flow direction (one inflow, one outflow edge)")
    (e_out, s_out), e_in = outs[0], ins[0][0]
    mdot = s_out * float(est[ES_MDOT, e_out])  # > 0
    hs_out = float(est[ES_HT, e_out]) - edge_formation_enthalpy(prob, x, e_out, moles=moles)
    hs_in = float(est[ES_HT, e_in]) - edge_formation_enthalpy(prob, x, e_in, moles=moles)
    return mdot * (hs_out - hs_in)
